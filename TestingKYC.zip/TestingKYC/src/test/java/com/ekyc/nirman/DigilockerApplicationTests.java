package com.ekyc.nirman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigilockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
