package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.payload.CmnResponse;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.rekyc.RekycRejectedDocuments;
import com.ekyc.nirman.enums.RejectDocument;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.RekycUserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class RekycRejectedDocsUploadService {

    private final RekycUserRepository rekycUserRepository;

    public RekycRejectedDocsUploadService(RekycUserRepository rekycUserRepository) {
        this.rekycUserRepository = rekycUserRepository;
    }
//    public CmnResponse uploadRejectedDocs(UUID userid, RekycRejectedDocuments rekycRejectedDocs) {
//        RekycUserDetailsDao rekycUserDetailsDao = rekycUserRepository.findById(userid).orElseThrow(()-> new BusinessException(ErrorCodes.REKYC_USER_ID_NOT_EXIST, HttpStatus.BAD_REQUEST));
//        // not full updated
//        if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.FINANCIAL_PROOF)) {
//            rekycUserDetailsDao.getRekycAdditionalDetailsDao().setFinancialProof(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.FINANCIAL_PROOF));
//        }
//        if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.BANK_PROOF)) {
//            rekycUserDetailsDao.getRekycAdditionalDetailsDao().setBankProof(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.BANK_PROOF));
//        }
//        if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.IMAGE)) {
//            rekycUserDetailsDao.getRekycAdditionalDetailsDao().setImage(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.IMAGE));
//        }
//        if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.SIGNATURE)) {
//            rekycUserDetailsDao.getRekycAdditionalDetailsDao().setSignature(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.SIGNATURE));
//        }
//        rekycUserDetailsDao.setRekycStatus(RekycStatus.REQUESTED);
//        rekycUserDetailsDao.setRejecetdDocsCommaSeprated(null);
//        rekycUserRepository.save(rekycUserDetailsDao);
//        return new CmnResponse("rejected documents are uploaded");
//    }
public CmnResponse uploadRejectedDocs(RekycRejectedDocuments rekycRejectedDocs) {
//    RekycUserDetailsDao rekycUserDetailsDao = rekycUserRepository.findById(userid).orElseThrow(()-> new BusinessException(ErrorCodes.REKYC_USER_ID_NOT_EXIST, HttpStatus.BAD_REQUEST));
    // not full updated
    if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.FINANCIAL_PROOF)) {
//        rekycUserDetailsDao.getRekycAdditionalDetailsDao().setFinancialProof(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.FINANCIAL_PROOF));
        System.out.println("--------------------- financial proof ");
    }
    if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.BANK_PROOF)) {
//        rekycUserDetailsDao.getRekycAdditionalDetailsDao().setBankProof(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.BANK_PROOF));
        System.out.println("--------------------- BANK_PROOF proof ");
    }
    if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.IMAGE)) {
//        rek/ycUserDetailsDao.getRekycAdditionalDetailsDao().setImage(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.IMAGE));
        System.out.println("---------------------     if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.IMAGE)) {\n proof ");
    }
    if(rekycRejectedDocs.getRejectedDocsList().containsKey(RejectDocument.SIGNATURE)) {
//        rekycUserDetailsDao.getRekycAdditionalDetailsDao().setSignature(rekycRejectedDocs.getRejectedDocsList().get(RejectDocument.SIGNATURE));
        System.out.println("--------------------- SIGNATURE proof ");
    }
//    rekycUserDetailsDao.setRekycStatus(RekycStatus.REQUESTED);
//    rekycUserDetailsDao.setRejecetdDocsCommaSeprated(null);
//    rekycUserRepository.save(rekycUserDetailsDao);
    return new CmnResponse("rejected documents are uploaded");
}
}
