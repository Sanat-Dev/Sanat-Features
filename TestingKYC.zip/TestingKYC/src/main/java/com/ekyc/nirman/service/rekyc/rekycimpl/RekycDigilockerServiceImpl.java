package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.AadharDataDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.AccessTokenDto;
import com.ekyc.nirman.entity.dto.PanCardDataDto;
import com.ekyc.nirman.entity.payload.DigilockerCodeAndChallenge;
import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.entity.payload.innerservice.AadharResponseData;
import com.ekyc.nirman.entity.rekyc.RekycDigilockerResponse;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.helper.CodeChallengerAndVerifier;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.service.AdapterDigilockerService;
import com.ekyc.nirman.service.rekyc.RekycDigilockerService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.UUID;

@Service
public class RekycDigilockerServiceImpl implements RekycDigilockerService {
    private final AdapterDigilockerService adapterDigilockerService;
    private final RekycUserRepository rekycUserRepository;
    private final CodeChallengerAndVerifier codeChallengerAndVerifier;
    public RekycDigilockerServiceImpl(AdapterDigilockerService adapterDigilockerService, RekycUserRepository rekycUserRepository, CodeChallengerAndVerifier codeChallengerAndVerifier) {
        this.adapterDigilockerService = adapterDigilockerService;
        this.rekycUserRepository = rekycUserRepository;
        this.codeChallengerAndVerifier = codeChallengerAndVerifier;
    }
    @Override
    public RekycDigilockerResponse getUserDocumentsDataFromDigilockerApi(UUID xuserid , DigilockerCodeAndChallenge digilockerCodeAndChallenge) {
        RekycUserDetailsDao rekycUserDetailsDao =  rekycUserRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        String codeChallenger = codeChallengerAndVerifier.getCodeVerifierOfUser(String.valueOf(xuserid));
        AccessTokenDto accessTokenDto = adapterDigilockerService.getAccessTokenApi(true, codeChallenger , digilockerCodeAndChallenge.getCode());
        AadharDataDao aadhar = adapterDigilockerService.get_e_AadhaarDataFromDigilocker(accessTokenDto.getAccess_token());
        String panUrl = adapterDigilockerService.getPanCardUrlOfUserFromIssuedDocuments(accessTokenDto.getAccess_token());
        rekycUserDetailsDao.setAadharDataDao(aadhar);
        if(Objects.isNull(panUrl)) {
            rekycUserRepository.save(rekycUserDetailsDao);
            return RekycDigilockerResponse.builder().aadharResponseData(convertAadharDaoToAadharResponseData(aadhar)).message("Unable to fetch your pan card please upload your pan card").build();
        }
        PanCardDao panCardDao = adapterDigilockerService.getPanCardDetailsFromXmlFile(accessTokenDto.getAccess_token(), panUrl);
        panCardDao.setPan_pdf(adapterDigilockerService.getPanCardVerificationPdf(accessTokenDto.getAccess_token(), panUrl));
        rekycUserDetailsDao.setPanCardDao(panCardDao);

        rekycUserRepository.save(rekycUserDetailsDao);
        return RekycDigilockerResponse.builder().aadharResponseData(convertAadharDaoToAadharResponseData(aadhar)).panCardDataDto(convertPanCardDaoToDto(panCardDao)).message("Succesfully fetch your Aadhar card and pan card").rekycStatus(RekycStatus.VERIFICATION).build();
    }
    // to avoid unnecessary dependency of object mapper to convert some dao to dto
    private PanCardDataDto convertPanCardDaoToDto(PanCardDao panCardDao) {
        return PanCardDataDto.builder().panNumber(panCardDao.getPanNumber())
                .gender(panCardDao.getGender())
                .dob(panCardDao.getDob())
                .name(panCardDao.getName()).build();
    }
    private AadharResponseData convertAadharDaoToAadharResponseData(AadharDataDao aadharDataDao) {
        return AadharResponseData.builder()
                .maskAadharNumber(aadharDataDao.getMaskAadharNumber())
                .name(aadharDataDao.getName())
                .aadharProfilePhotoBase64(aadharDataDao.getAadharProfilePhotoBase64())
                .careOf(aadharDataDao.getCareOf())
                .dob(aadharDataDao.getDob()).build();
    }
    @Override
    public CodeChallenger createCodeChallengerAndSaveCodeVerifier(String xuserid) {
        return codeChallengerAndVerifier.getCodeChallengerAndSaveCodeVerifier(xuserid);
    }
}
