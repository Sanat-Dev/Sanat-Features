package com.ekyc.nirman.entity.dto.rekyc;

import com.ekyc.nirman.entity.dto.AddressDto;
import lombok.Data;

@Data
public class RekycBankDetails {
    private String bankName;
    private String micr ;
    private String ifsc ;
    private String accountType ;
    private String accountNumber ;
}
