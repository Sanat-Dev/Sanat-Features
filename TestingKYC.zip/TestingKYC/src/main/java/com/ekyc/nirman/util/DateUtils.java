package com.ekyc.nirman.util;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DateUtils {
    private final static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private final static DateTimeFormatter formatterSecond = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private final static DateTimeFormatter formatterWithoutSpecialsChar = DateTimeFormatter.ofPattern("ddMMyyyy");
    private final static DateTimeFormatter hourSecondFormatter = DateTimeFormatter.ofPattern("ddHHmmss");
    private final static DateTimeFormatter ddmmyyhhssFormatter = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
    // it should be change to appropriate zoneId time of utf
    private final static ZoneId zoneId = ZoneId.systemDefault();
    public static String longEpochTimeToDDMMYYYYSeparateWithSlash(long time) {
        Instant instant = Instant.ofEpochMilli(time);
        LocalDate localDate = instant.atZone(zoneId).toLocalDate();
        return localDate.format(formatter);
    }

    public static String simpleDateFormatterWithoutSpecialCharacter() {
        return formatterWithoutSpecialsChar.format(LocalDateTime.now());
    }
    public static String getCurrentDateInFormateDDMMYYYY() {
        return formatter.format(LocalDateTime.now());
    }
    public static String getCurrentDateInFormateDDMMYYYYSeparateWithHypen() {
        return formatterSecond.format(LocalDateTime.now());
    }
    public static String longEpochTimeToDDMMYYYYSeparateWithHypen(long time) {
        Instant instant = Instant.ofEpochMilli(time);
        LocalDate localDate = instant.atZone(zoneId).toLocalDate();
        return localDate.format(formatterSecond);
    }
    /**
     *  current time is 14:30:45, it will produce the string "11143045".
     * */
    public static  String getCurrentDateTimeSecondToReference() {
       return hourSecondFormatter.format(LocalDateTime.now());
    }
    /**
     * this function will convert inputDate 12-01-2012 to this 12-01-2012
     * */
    public  static  String convertHypenDateToSlashAddedDate(String inputDate) {
        StringBuilder convertedDate = new StringBuilder();
        for (int i = 0; i < inputDate.length(); i++) {
            if (inputDate.charAt(i) == '-') {
                convertedDate.append('/');
            } else {
                convertedDate.append(inputDate.charAt(i));
            }
        }
        return convertedDate.toString();
    }

    public static String removeHypenFromDateType(String inputDate) {
        StringBuilder convertedDate = new StringBuilder();
        for (int i = 0; i < inputDate.length(); i++) {
            if(inputDate.charAt(i) != '-') {
                convertedDate.append(inputDate.charAt(i));
            }
        }
        return  convertedDate.toString();
    }
    public static String createCurrentDateInDDMMYYYYHHSS() {
        return ddmmyyhhssFormatter.format(LocalDateTime.now());
    }
}
