package com.ekyc.nirman.entity.payload;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CmnResponse {
    private String message;
    public CmnResponse(String message) {
        this.message = message;
    }
}
