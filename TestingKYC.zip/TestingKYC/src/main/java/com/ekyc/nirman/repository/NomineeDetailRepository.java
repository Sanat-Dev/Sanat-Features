package com.ekyc.nirman.repository;

import com.ekyc.nirman.entity.dao.BasicDetailsDao.NomineeDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface NomineeDetailRepository extends JpaRepository<NomineeDao, UUID> {
}
