package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.AddressDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.GuardianDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.NomineeDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.SubscriptionList;
import com.ekyc.nirman.entity.dao.rekyc.RekycAdditionalDetailsDao;
import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.NomineeDto;
import com.ekyc.nirman.entity.dto.rekyc.RekycCommonResponse;
import com.ekyc.nirman.entity.rekyc.RekycSubmitDetails;
import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.service.rekyc.RekycUserOtherDetailsSubmitService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
public class RekycUserSubmitDetailsServiceImpl implements RekycUserOtherDetailsSubmitService {
    private final Logger _logger = LoggerFactory.getLogger(RekycUserSubmitDetailsServiceImpl.class);
    private final ObjectMapper objectMapper;
    private final RekycUserRepository rekycUserRepository;

    public RekycUserSubmitDetailsServiceImpl(ObjectMapper objectMapper, RekycUserRepository rekycUserRepository) {
        this.objectMapper = objectMapper;
        this.rekycUserRepository = rekycUserRepository;
    }

    @Override
    public RekycCommonResponse addAdditionalUserDetails(UUID xuserid , RekycSubmitDetails rekycSubmitDetails) {
        RekycAdditionalDetailsDao rekycAdditionalDetails = objectMapper.convertValue(rekycSubmitDetails, RekycAdditionalDetailsDao.class);
        RekycUserDetailsDao rekycUserDetailsDB = rekycUserRepository.findById(xuserid).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED , HttpStatus.UNAUTHORIZED));
        rekycUserDetailsDB.setRekycAdditionalDetailsDao(rekycAdditionalDetails);
        rekycUserDetailsDB.setLockStatus(RekycLockStatus.LOCKED);
        rekycUserDetailsDB.setRekycStatus(RekycStatus.REQUESTED);
        _logger.info("---------- here 1");
        _logger.info("---------------------- user rekycdetails {} ", rekycSubmitDetails);
        // adding details of multiple nominee in db
        List<NomineeDao> listOfNomineeInfo = new ArrayList<>();
        for(NomineeDto nomineeDto : rekycSubmitDetails.getNominee()) {
            NomineeDao nb = objectMapper.convertValue(nomineeDto, NomineeDao.class);
            nb.setAddressDao(objectMapper.convertValue(nomineeDto.getAddressDto(), AddressDao.class));
            // can be removed if frontend give appropriate object of guardian
            if(!Objects.isNull(nomineeDto.getGuardianName())) {
                GuardianDao guardianDB = new GuardianDao();
                guardianDB.setName(nomineeDto.getGuardianName());
                guardianDB.setAddress(nomineeDto.getGuardianAddress());
                guardianDB.setIdProofNo(nomineeDto.getGuardianIdProof());
                guardianDB.setRelationWithNominee(nomineeDto.getRelation());
                nb.setGuardianDao(guardianDB);
            }
            listOfNomineeInfo.add(nb);
        }
        _logger.info("---------- here 1");
        rekycUserDetailsDB.setNomineeDao(listOfNomineeInfo);
        // segment list addition details when user select one data
        StringBuilder segmentListCommaSeprated = new StringBuilder();
        _logger.info("---------- here 1");
        for(String x : rekycSubmitDetails.getNewSegmentList()) {
            segmentListCommaSeprated.append(x).append(",");
        }
        _logger.info("---------- here 1");
        if(segmentListCommaSeprated.length()>0) {
            segmentListCommaSeprated.setLength(segmentListCommaSeprated.length()-1);
        }
        _logger.info("---------- here 1");
        rekycUserDetailsDB.setNewSegmentSelectionCommaSeprated(segmentListCommaSeprated.toString());
        rekycUserDetailsDB.setSubscriptionList(new SubscriptionList());
        _logger.info("---------- here 1");
        rekycUserRepository.save(rekycUserDetailsDB);
        return RekycCommonResponse.builder().rekycStatus(RekycStatus.REQUESTED).message("rekyc Application added").build();
    }

    public RekycCommonResponse submitEsignUrlUpload(UUID userid, String documentId) {
        RekycUserDetailsDao user = rekycUserRepository.findById(userid).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED , HttpStatus.UNAUTHORIZED));
        user.setLeegalityDocsId(documentId);
        user.setRekycStatus(RekycStatus.ESIGNED);
        rekycUserRepository.save(user);
        return RekycCommonResponse.builder().message("rekyc Application added").build();
    }
}
