package com.ekyc.nirman.entity.payload.response;

import com.ekyc.nirman.enums.KycStatus;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class KycStageResponse {
    private UUID userId ;
    private KycStatus kycStatus;
}
