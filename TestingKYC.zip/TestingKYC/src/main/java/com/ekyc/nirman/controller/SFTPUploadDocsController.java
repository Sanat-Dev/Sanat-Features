package com.ekyc.nirman.controller;

import com.ekyc.nirman.service.SFTPService;
import com.ekyc.nirman.service.impl.SFTPServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/")
public class SFTPUploadDocsController {
    /**
     * @Author : Sanat Jain
     *
     * */

    @Autowired
    SFTPService sftpService;

    @PostMapping("upload/docs/csdlvl")
    public String uploadFiles(@RequestParam(value = "from", required = true) String fromPath){
    return sftpService.uploadToSFTPFiles(fromPath);
    }


}
