package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.payload.DigilockerCodeAndChallenge;
import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.entity.rekyc.RekycDigilockerResponse;
import com.ekyc.nirman.service.rekyc.RekycDigilockerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("api/v1/rekyc/digilocker")
class RekycDigilockerController {
    private final RekycDigilockerService rekycDigilockerService;
    RekycDigilockerController(RekycDigilockerService rekycDigilockerService) {
        this.rekycDigilockerService = rekycDigilockerService;
    }
    @GetMapping("/code/challenger")
    public ResponseEntity<CodeChallenger> getDetailsOfCodeChallenger(@RequestHeader("xuserid") String xuserid ) {
        return ResponseEntity.ok(rekycDigilockerService.createCodeChallengerAndSaveCodeVerifier(xuserid));
    }

    @PostMapping("/access-details/user")
    public ResponseEntity<RekycDigilockerResponse> accessDigilockerData(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid DigilockerCodeAndChallenge digilockerCodeAndChallenge) {
        return ResponseEntity.ok(rekycDigilockerService.getUserDocumentsDataFromDigilockerApi(UUID.fromString(xuserid), digilockerCodeAndChallenge));
    }
}
