package com.ekyc.nirman.entity.payload.innerservice;

import lombok.*;

@Builder
@Data
@AllArgsConstructor
public class IfscCodeResponse {
    private String name ;
    private String micr ;
    private String branch;
    private String address ;
}
