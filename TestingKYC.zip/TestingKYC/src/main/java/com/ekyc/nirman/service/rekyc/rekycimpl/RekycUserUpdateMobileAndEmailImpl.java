package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationRequest;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.service.otpservicehelper.GenericOtpService;
import com.ekyc.nirman.service.rekyc.RekycUserUpdateMobileAndEmail;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class RekycUserUpdateMobileAndEmailImpl implements RekycUserUpdateMobileAndEmail {
    private final GenericOtpService genericOtpService;
    private final RekycUserRepository rekycUserRepository;
    public RekycUserUpdateMobileAndEmailImpl(GenericOtpService genericOtpService, RekycUserRepository rekycUserRepository) {
        this.genericOtpService = genericOtpService;
        this.rekycUserRepository = rekycUserRepository;
    }
    public OtpVerificationResponse verifyAndUpdateUserRequestedDeviceDetails(UUID xuserid, NotificationType notificationType, OtpVerificationRequest otpRequest) {
        OtpVerificationResponse otpVerificationResponse = genericOtpService.verifyOtpOfUser(otpRequest.getUserKey(), otpRequest.getOtp());
        if(!otpVerificationResponse.isVerified()) return otpVerificationResponse;
        switch (notificationType) {
            case SMS: {
                savePhoneNumberInDB(xuserid, otpRequest.getUserKey());
                break;
            }
            case EMAIL: {
                saveEmailInDB(xuserid, otpRequest.getUserKey());
                break;
            }
        }
        return otpVerificationResponse;
    }

    private void savePhoneNumberInDB(UUID xuserid, String phoneNumber) {
        RekycUserDetailsDao rekycUserDetailsDao = rekycUserRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
        rekycUserDetailsDao.setNewMobile(phoneNumber);
        rekycUserRepository.save(rekycUserDetailsDao);
    }
    private void saveEmailInDB(UUID xuserid, String email) {
        RekycUserDetailsDao rekycUserDetailsDao = rekycUserRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
        rekycUserDetailsDao.setNewEmail(email);
        rekycUserRepository.save(rekycUserDetailsDao);
    }
    public DeviceOtpResponse sendOtpToUserRequestedDevice(NotificationType notificationType, DeviceOtpRequest deviceOtpRequest) {
        String otp = genericOtpService.generateOtpForDevice();
        genericOtpService.saveOtpInRedisCacheMemory(deviceOtpRequest.getValue(), otp, 10);
        genericOtpService.sendOtpToUser(deviceOtpRequest.getValue(), notificationType, Map.of("name" , "", "otp", otp));
        return new DeviceOtpResponse("Otp is successfully sent.");
    }
}
