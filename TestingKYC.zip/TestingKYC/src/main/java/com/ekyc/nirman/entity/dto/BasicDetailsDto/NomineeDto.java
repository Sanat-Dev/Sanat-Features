package com.ekyc.nirman.entity.dto.BasicDetailsDto;

import com.ekyc.nirman.entity.dto.AddressDto;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class NomineeDto {
    @NotNull(message = "name field should not empty")
    private String name ;
    @NotNull(message = "date of birth field should not empty")
    private String dateOfBirth;
    @NotNull(message = "contact number should not empty")
    private String contactNumber ;
    @NotNull(message = "email field should not empty")
    private String email ;
    @NotNull(message = "relation between nominee should not empty")
    private String relation ;
    private String proofOfAddress ;
    @NotNull(message = "document type is required")
    private String typeOfDocument;
    @NotNull(message = "poi reference number should not empty")
    private String poiReferenceNumber;
    private AddressDto addressDto ;
    @NotNull(message = "share percentage field should not empty")
    private String sharePercentage ;
    // guardian address proof
    private String guardianIdProof;
    private String guardianName;
    private String guardianRelation;
    private String guardianAddress;
    private String guardianIdProofNumber;
}
