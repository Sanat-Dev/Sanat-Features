package com.ekyc.nirman.controller.closure;

import com.ekyc.nirman.entity.dto.SuccessResponse;
import com.ekyc.nirman.entity.dto.closure.Closure;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.dto.otpResponse.RekycOtpVerificationRequest;
import com.ekyc.nirman.entity.dto.rekyc.RekycBackOfficeUserDetails;
import com.ekyc.nirman.service.closure.ClosureService;;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Objects;

@RestController
@RequestMapping("api/v1/closure")
public class UserAccountClosure {

    private final ClosureService closureService;

    public UserAccountClosure(ClosureService closureService) {
        this.closureService = closureService;
    }

    @PostMapping("/push/data")
    public ResponseEntity<?> pushClosureDetailsInDb(@RequestBody @Valid Closure closure) {
        return  ResponseEntity.ok(closureService.addDetailsToClosureDbRepo(closure));
    }

    @PostMapping("/user/verify/otp")
    public ResponseEntity<?> verifyClientOtpOfUser(@Valid @RequestBody RekycOtpVerificationRequest rekycOtpVerificationRequest) {
        RekycBackOfficeUserDetails rekycDetails = closureService.userVerficationUsingOtp(rekycOtpVerificationRequest.getDpId(), rekycOtpVerificationRequest.getOtp());
        return (Objects.isNull(rekycDetails))? new ResponseEntity<>(OtpVerificationResponse.builder().message("invalid credential").build() , HttpStatus.UNAUTHORIZED): ResponseEntity.ok(rekycDetails);
    }

    @PostMapping("/closureAccount/pdfesign")
    public ResponseEntity<SuccessResponse> getPdfEsign(@RequestBody Closure closure){
         return ResponseEntity.ok(closureService.addDetailsToClosureDbRepo(closure));
    }


}
