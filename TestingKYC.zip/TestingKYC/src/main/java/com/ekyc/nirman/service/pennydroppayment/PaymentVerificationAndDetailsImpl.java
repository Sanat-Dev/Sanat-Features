package com.ekyc.nirman.service.pennydroppayment;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.payload.innerservice.IfscCodeResponse;
import com.ekyc.nirman.entity.payload.innerservice.RazorPayResponse;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PaymentVerificationAndDetailsImpl implements PaymentVerificationAndDetails {

    @Autowired
    TenantConstants tenantConstants;

    private final OkHttpClient client;
    private final ObjectMapper objectMapper;
    private String rajorPayFundAccAdminContactId = tenantConstants.RAZORPAY_FUND_CLIENT_CONTACT_ID;
    private String rajorPayClientAuthUserName = tenantConstants.RAZORPAY_FUND_CLIENT_AUTH_USERNAME;
    private String rajorPayClientAuthUserPassword = tenantConstants.RAZORPAY_FUND_CLIENT_AUTH_USERPASSWORD;
    private String rajorPayClientAccNo = tenantConstants.RAZORPAY_FUND_CLIENT_ACCOUNT_NO;

    public PaymentVerificationAndDetailsImpl(OkHttpClient client, ObjectMapper objectMapper) {
        this.client = client;
        this.objectMapper = objectMapper;
    }

    public String createFundAccountOfUser(BankDetailsDto bankDetails) {
        String jsonBody = "{\"contact_id\":\"" + rajorPayFundAccAdminContactId + "\",\"account_type\":\"bank_account\",\"bank_account\":{\"name\":\"" +
                bankDetails.getName() +
                "\",\"ifsc\":\"" + bankDetails.getIfsc() + "\",\"account_number\":\"" +
                bankDetails.getAccountNumber() + "\"}}";
        log.info("------------------ json body of request {}========", jsonBody);
        Request request = new Request.Builder()
                .url("https://api.razorpay.com/v1/fund_accounts")
                .addHeader("Content-Type" ,"application/json")
                .addHeader("Authorization", Credentials.basic(rajorPayClientAuthUserName, rajorPayClientAuthUserPassword))
                .post(RequestBody.create(MediaType.parse("application/json"), jsonBody))
                .build();

        String fundId = null;
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                int startIndex = responseBody.indexOf("\"id\":\"") + 6;
                int endIndex = responseBody.indexOf("\"", startIndex);
                fundId = responseBody.substring(startIndex, endIndex);
                log.info("-------------fund id {}", fundId);
                if (fundId.equals("or")) {
                    log.info("----------------- Authentication of admin side is failed :: Authentication is failed :: Change O-Auth creadential :: ");
                    throw new BusinessException(ErrorCodes.CREDENTIAL_ARE_INVALID, HttpStatus.BAD_REQUEST);
                }
                return fundId;
            } else {
                throw new BusinessException(ErrorCodes.PAYMENT_IS_NOT_BEEN_INSTANTIATE, HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            log.info("--------------- request of payment is unsuccessful in createFundAccountOfUser {}", bankDetails);
            throw new BusinessException(ErrorCodes.PAYMENT_IS_NOT_BEEN_INSTANTIATE, HttpStatus.BAD_REQUEST);
        }
    }
    public RazorPayResponse validateBankDetailsOfUserUsingRazorPay(String fundId) {
        log.info("------------fundId for created user : ------- {}", fundId);
        String jsonRequest = "{\"account_number\": \""+rajorPayClientAccNo+"\", \"fund_account\":{\"id\":\""
                + fundId
                + "\"},\"amount\": 100,\"currency\": \"INR\",\"notes\": {\"random_key_1\":\"Make it so.\",\"random_key_2\":\"Tea. Earl Grey. Hot.\"}}";
        log.info("===================== json request {}", jsonRequest);
        Request request = new Request.Builder()
                .url("https://api.razorpay.com/v1/fund_accounts/validations")
                .addHeader("Content-Type" ,"application/json")
                .addHeader("Authorization", Credentials.basic(rajorPayClientAuthUserName, rajorPayClientAuthUserPassword))
                .post(RequestBody.create(MediaType.parse("application/json"), jsonRequest))
                .build();
        try (Response response = client.newCall(request).execute()) {
            if(response.isSuccessful()) {
                JsonNode jsonNode = objectMapper.readTree(response.body().string());
                RazorPayResponse razorPayResponse = new RazorPayResponse();
                razorPayResponse.setPayoutId(jsonNode.get("id").asText());
                razorPayResponse.setStatus(jsonNode.get("status").asText());
                JsonNode resultNode = jsonNode.get("results");
                razorPayResponse.setRegisteredName(resultNode.get("registered_name" ).asText());
                razorPayResponse.setPennyDropReason(resultNode.toString());
                return  razorPayResponse;
            } else {
                log.info("----------------- :: Authentication of admin side is failed :: Authentication is failed :: Change O-Auth creadential :: ");
                throw new BusinessException(ErrorCodes.CREDENTIAL_ARE_INVALID, HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.PAYMENT_IS_NOT_BEEN_INSTANTIATE, HttpStatus.BAD_REQUEST);
        }
    }
    public IfscCodeResponse getBankDetailFromIfscCode(String ifscCode) {
        Request request = new Request.Builder()
                .url("https://ifsc.razorpay.com/"+ifscCode)
                .addHeader("Content-Type" ,"application/json")
                .get().build();
        try (Response response = client.newCall(request).execute()) {
            JsonNode jsonNode = objectMapper.readTree(response.body().string());
            IfscCodeResponse ifscData = IfscCodeResponse.builder()
                    .name(jsonNode.get("BANK").asText())
                    .micr(jsonNode.get("MICR").asText())
                    .address(jsonNode.get("ADDRESS").asText())
                    .branch(jsonNode.get("BRANCH").asText())
                    .build();
            return ifscData;
        } catch (Exception e){
            throw new BusinessException(ErrorCodes.IFSC_CODE_DOES_NOT_MATCH , HttpStatus.BAD_REQUEST);
        }
    }
}
