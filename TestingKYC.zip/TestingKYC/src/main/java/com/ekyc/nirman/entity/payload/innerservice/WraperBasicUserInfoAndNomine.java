package com.ekyc.nirman.entity.payload.innerservice;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.BasicUserInfoDto;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.ListofNomineeMembersInfo;
import lombok.Data;

import javax.validation.Valid;

@Data
public class WraperBasicUserInfoAndNomine {
    @Valid
    private BasicUserInfoDto basicUserInfoDto;
    private ListofNomineeMembersInfo listofNomineeMembersInfo;
}
