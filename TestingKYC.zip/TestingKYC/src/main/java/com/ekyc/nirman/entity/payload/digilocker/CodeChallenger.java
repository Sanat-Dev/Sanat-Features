package com.ekyc.nirman.entity.payload.digilocker;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CodeChallenger {
    private String codeChallenger ;
}
