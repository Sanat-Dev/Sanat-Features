package com.ekyc.nirman.entity.payload.innerservice;

import com.ekyc.nirman.enums.KycStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class CommonResponse {
    private String message ;
    private KycStatus kycStatus ;
}
