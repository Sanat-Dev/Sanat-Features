package com.ekyc.nirman.controller;

import com.ekyc.nirman.service.LegalityService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/esign")
public class LeegalityController {
    private final LegalityService legalityService;

    public LeegalityController(LegalityService legalityService) {
        this.legalityService = legalityService;
    }

    @GetMapping("/esign/{esignId}")
    ResponseEntity<?> saveEsignPdfDocument(@RequestHeader("xuserid") String xuserid,  @PathVariable(name = "esignId") String esignId) {
        return ResponseEntity.ok(this.legalityService.saveEsignDocumetId(UUID.fromString(xuserid), esignId));
    }
    @GetMapping("/register/callback")
    ResponseEntity<String> pingFromRedirect(@RequestParam(name = "phone") String phoneNumber, @RequestParam("documentId") String documentId, @RequestParam("isrekyc") String isrekyc) {
        return ResponseEntity.ok(this.legalityService.saveEsignDocumentInDatabase(phoneNumber, documentId, isrekyc));
    }
}
