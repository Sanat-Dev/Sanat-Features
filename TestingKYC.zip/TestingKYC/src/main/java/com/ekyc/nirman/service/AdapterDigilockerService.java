package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.dao.AadharDataDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dto.AccessTokenDto;

public interface AdapterDigilockerService {
    AccessTokenDto getAccessTokenApi(boolean isRekyc, String codeVerifier, String code);
    String getPanCardUrlOfUserFromIssuedDocuments(String bearer);
    PanCardDao getPanCardDetailsFromXmlFile(String accessToken, String uri);
    byte[] getPanCardVerificationPdf(String bearer, String uri);
    AadharDataDao get_e_AadhaarDataFromDigilocker(String bearer);
}
