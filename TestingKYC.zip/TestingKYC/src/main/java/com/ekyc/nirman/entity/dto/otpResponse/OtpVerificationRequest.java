package com.ekyc.nirman.entity.dto.otpResponse;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Data
public class OtpVerificationRequest {
    @NotNull(message = "mobile/email address can not be empty")
    @NotBlank(message = "field value should be greater then 0")
    private String userKey ;
    @NotNull(message = "otp field can not be empty ")
    private String otp ;
}
