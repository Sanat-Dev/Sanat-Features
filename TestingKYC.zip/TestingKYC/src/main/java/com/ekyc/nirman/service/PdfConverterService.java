package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.payload.response.PdfFile;

import java.util.UUID;

public interface PdfConverterService {
    PdfFile convertIntoPdf(UUID xuserid);
}
