package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.payload.DigilockerCodeAndChallenge;
import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.entity.payload.digilocker.PanCardDetails;
import com.ekyc.nirman.entity.payload.digilocker.DigilockerResponse;

import java.util.UUID;

public interface DigilockerService {
        DigilockerResponse getAccessTokenApi(UUID xuserid, DigilockerCodeAndChallenge digilockerCodeAndChallenge);
        CodeChallenger getCodeChallenger(String xuserid);
        DigilockerResponse uploadPanCardDetailsOfUser(UUID xuserid, PanCardDetails panCardDetails);
}
