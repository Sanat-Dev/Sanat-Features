package com.ekyc.nirman.entity.payload.digilocker;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class PanCardDetails {
    @NotNull(message = "name should not empty")
    private String name ;
    @NotNull(message = "date of Birth should not empty")
    private String dob ;
    @NotNull(message = "pan number should not empty")
    private String panNumber ;
    @NotNull(message = "pan card image should not empty")
    private String panCardImage ;
}
