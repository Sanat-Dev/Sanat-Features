package com.ekyc.nirman.entity.payload.innerservice;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ImageAndSignatureDto {
    @NotNull(message = "image can not be empty")
    private String image ;
    @NotNull(message = "signature can not be empty")
    private String signature ;
    @NotNull(message = "location should not be empty")
    private Geolocation geolocation ;
}
