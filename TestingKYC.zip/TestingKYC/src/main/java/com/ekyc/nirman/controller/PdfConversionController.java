package com.ekyc.nirman.controller;

import com.ekyc.nirman.service.PdfConverterService;
import com.ekyc.nirman.service.impl.PdfConverterImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/convert")
public class PdfConversionController {
    private final PdfConverterService pdfConverterService ;
    private final PdfConverterImpl pdfConverter;

    public PdfConversionController(PdfConverterService pdfConverterService, PdfConverterImpl pdfConverter) {
        this.pdfConverterService = pdfConverterService;
        this.pdfConverter = pdfConverter;
    }

    @GetMapping("/pdf")
    ResponseEntity<?> createPdfOfUser(@RequestHeader("xuserid") String xuserid){
        return  ResponseEntity.ok(pdfConverterService.convertIntoPdf(UUID.fromString(xuserid)));
    }
}
