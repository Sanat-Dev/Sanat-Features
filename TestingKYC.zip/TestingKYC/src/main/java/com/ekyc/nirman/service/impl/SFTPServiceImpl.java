package com.ekyc.nirman.service.impl;


import com.ekyc.nirman.service.SFTPService;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

@Service
public class SFTPServiceImpl implements SFTPService {

    /**
     * @Author : Sanat Jain
     *
     * */
    private final Logger _logger = LoggerFactory.getLogger(SFTPServiceImpl.class);
    private final String USERNAME;
    private final String PASSWORD;

    public SFTPServiceImpl(@Value("sftp.nirman.username") final String username, @Value("sftp.nirman.password") final String password) {
        USERNAME = username;
        PASSWORD = password;
    }

    public String uploadToSFTPFiles(String fromPath) {

        Date currentDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
        String formattedDate = formatter.format(currentDate);
        String remoteFolderPath = formattedDate + "/CVLKRA/";
        final String HOST = "dm.cvlindia.com";
        final int PORT = 4443;
        final String LOCAL_FOLDER_PATH = fromPath;
        final String REMOTE_FOLDER_PATH = remoteFolderPath;


        Session session = null;
        ChannelSftp channelSftp = null;

        try {
            JSch jsch = new JSch();
            session = jsch.getSession(USERNAME, HOST, PORT);
            session.setPassword(PASSWORD);

            // Avoid asking for key confirmation
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);

            session.connect();
            _logger.info("-----------------------Connected to SFTP server");
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();

            File localFolder = new File(LOCAL_FOLDER_PATH);
            File[] files = localFolder.listFiles();

            if (files != null) {
                for (File file : files) {
                    if (!file.isDirectory()) {
                        String localFilePath = file.getAbsolutePath();
                        String remoteFilePath = REMOTE_FOLDER_PATH + file.getName();
                        channelSftp.put(localFilePath, remoteFilePath);
                        _logger.info("----------------------- File \"{}\" uploaded successfully", file.getName());
                    }
                }
            }
            _logger.info("----------------------- Disconnected from SFTP server");
            return "Upload Successful";
        } catch (Exception e) {
            _logger.error("=========ERROR -= Something went wrong !!! {}",e.getMessage());
            return "Upload Failed";
        } finally {
            if (channelSftp != null && channelSftp.isConnected()) {
                channelSftp.disconnect();
            }
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
        }
    }
}
