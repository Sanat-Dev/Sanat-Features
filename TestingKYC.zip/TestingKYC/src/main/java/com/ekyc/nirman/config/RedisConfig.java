package com.ekyc.nirman.config;

import com.ekyc.nirman.entity.payload.otppayload.OtpInRedis;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
public class RedisConfig {
    @Bean
    public JedisConnectionFactory getConnectionFactory(){
        JedisConnectionFactory connectionFactory = new JedisConnectionFactory();
        return connectionFactory;
    }
    @Bean
    public RedisTemplate<String, OtpInRedis> redisTemplate() {
        RedisTemplate<String, OtpInRedis> redisTemplate = new RedisTemplate<String, OtpInRedis>();
        redisTemplate.setConnectionFactory(getConnectionFactory());
        return redisTemplate;
    }

    @Bean
    RedisTemplate<String , String> redisDataCodeChallenger() {
        RedisTemplate<String, String> redisTemplate = new RedisTemplate<String, String>();
        redisTemplate.setConnectionFactory(getConnectionFactory());
        return redisTemplate;
    }
}
