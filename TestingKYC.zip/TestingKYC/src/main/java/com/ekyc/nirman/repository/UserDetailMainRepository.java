package com.ekyc.nirman.repository;

import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserDetailMainRepository extends JpaRepository<UserDetailMainDao , UUID>{
    Optional<UserDetailMainDao> findByPhoneNumber(String phoneNumber);
    Optional<UserDetailMainDao> findTopByOrderByClientCodeDesc();
}
