package com.ekyc.nirman.controller;

import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;
import com.ekyc.nirman.entity.payload.otppayload.EmailOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.MobileOtpRequest;
import com.ekyc.nirman.entity.payload.response.EmailResponse;
import com.ekyc.nirman.entity.payload.otppayload.MobileOtpResponse;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.service.EkycOtpService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Objects;
import java.util.UUID;

@RestController
@RequestMapping("api/v1/otp")
public class OtpController {
    private final EkycOtpService ekycOtpService;

    public OtpController(EkycOtpService ekycOtpService) {
        this.ekycOtpService = ekycOtpService;
    }

    @PostMapping("/send")
    ResponseEntity<DeviceOtpResponse> sendOtpToPhone(@RequestParam("type") NotificationType notificationType, @RequestBody DeviceOtpRequest deviceOtpRequest) {
        return new ResponseEntity(this.ekycOtpService.sendOtpToUser(deviceOtpRequest, notificationType), HttpStatus.OK);
    }
    @PostMapping("/verify-mobile")
    ResponseEntity<MobileOtpResponse> verifyMobileOtp(@RequestParam(name = "rm", required = false) String rmname, @Valid @RequestBody MobileOtpRequest mobileOtpRequest) {
        MobileOtpResponse m = this.ekycOtpService.verifyMobileOtp(mobileOtpRequest, rmname);
        return (Objects.isNull(m.getUserid())) ? new ResponseEntity(m, HttpStatus.BAD_REQUEST) : ResponseEntity.ok(m);
    }
    @PostMapping("/verify-email")
    ResponseEntity<?> verifyEmailOtp(@RequestHeader("xuserid") UUID xuserid, @Valid @RequestBody EmailOtpRequest emailOtpRequest) {
        System.out.println("-------------- xuserid" + xuserid);
        EmailResponse emailResponse = this.ekycOtpService.verifyEmailOtp(xuserid, emailOtpRequest);
        return emailResponse.getKycStatus().equals(KycStatus.DIGILOCKER) ? ResponseEntity.ok(emailResponse) : new ResponseEntity(emailResponse, HttpStatus.BAD_REQUEST);
    }
}
