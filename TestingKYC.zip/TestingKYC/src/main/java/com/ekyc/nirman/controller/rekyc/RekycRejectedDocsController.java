package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.payload.CmnResponse;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.rekyc.RekycRejectedDocuments;
import com.ekyc.nirman.service.rekyc.rekycimpl.RekycRejectedDocsUploadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("api/v1")
public class RekycRejectedDocsController {
    private final RekycRejectedDocsUploadService rekycRejectedDocsUploadService;
    public RekycRejectedDocsController(RekycRejectedDocsUploadService rekycRejectedDocsUploadService) {
        this.rekycRejectedDocsUploadService = rekycRejectedDocsUploadService;
    }
//    @PostMapping("rekyc/rejected/docs/submit")
//    public ResponseEntity<CmnResponse> submitRejectedDocumentList(@RequestHeader("xuserid") UUID userid , @RequestBody @Valid RekycRejectedDocuments rekycRejectedDocs) {
//        return ResponseEntity.ok(rekycRejectedDocsUploadService.uploadRejectedDocs(userid, rekycRejectedDocs));
//    }
    @PostMapping("rekyc/rejected/docs/submit")
    public ResponseEntity<CmnResponse> submitRejectedDocumentList(@RequestBody @Valid RekycRejectedDocuments rekycRejectedDocs) {
        return ResponseEntity.ok(rekycRejectedDocsUploadService.uploadRejectedDocs(rekycRejectedDocs));
    }

}
