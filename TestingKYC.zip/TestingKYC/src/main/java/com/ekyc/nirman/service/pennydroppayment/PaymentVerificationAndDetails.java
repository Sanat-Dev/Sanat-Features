package com.ekyc.nirman.service.pennydroppayment;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.payload.innerservice.IfscCodeResponse;
import com.ekyc.nirman.entity.payload.innerservice.RazorPayResponse;

public interface PaymentVerificationAndDetails {
    String createFundAccountOfUser(BankDetailsDto bankDetails);
    RazorPayResponse validateBankDetailsOfUserUsingRazorPay(String fundId);
    IfscCodeResponse getBankDetailFromIfscCode(String ifscCode);
}
