package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;
import com.ekyc.nirman.entity.payload.otppayload.EmailOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.MobileOtpRequest;
import com.ekyc.nirman.entity.payload.response.EmailResponse;
import com.ekyc.nirman.entity.payload.otppayload.MobileOtpResponse;
import com.ekyc.nirman.enums.NotificationType;

import java.util.UUID;

public interface EkycOtpService {
    DeviceOtpResponse sendOtpToUser(DeviceOtpRequest deviceOtpRequest, NotificationType notificationType);
    MobileOtpResponse verifyMobileOtp(MobileOtpRequest mobileOtpRequest, String rmname);
    EmailResponse verifyEmailOtp(UUID id, EmailOtpRequest emailOtpRequest);

}
