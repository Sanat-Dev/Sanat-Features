package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.service.rekyc.RekycBackOfficeDataApi;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@Slf4j
public class RekycRekycBackOfficeDataApiImpl implements RekycBackOfficeDataApi {

    @Autowired
    TenantConstants tenantConstants;

    private String backOfficeUrl =tenantConstants.BACK_OFFICE_URL;
    private OkHttpClient client = new OkHttpClient();

    @Override
    @Async
    public String backOfficeApiDataUsingDpid(String dpId) {
        Request request = new Request.Builder()
                .url(backOfficeUrl + dpId)
                .addHeader("Content-Type" ,"application/json")
                .get()
                .build();
        Call call = client.newCall(request);
        String jsonResponse = null;
        Response response = null;
        try {
            response = call.execute();
            jsonResponse = response.body().string();
            if(!response.isSuccessful()) throw new BusinessException(ErrorCodes.BACK_OFFICE_CANNOT_BE_ABLE_TO_CALL, HttpStatus.BAD_REQUEST);
            log.info("-------------- after calling method value is ::: {}", jsonResponse);
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.BACK_OFFICE_CANNOT_BE_ABLE_TO_CALL, HttpStatus.BAD_REQUEST);
        } finally {
            if(Objects.isNull(response)){
                response.close();
            }
        }
        if(Objects.isNull(jsonResponse)) {
            throw new BusinessException(ErrorCodes.DPID_IS_NOT_VALID, HttpStatus.UNAUTHORIZED);
        }
        return jsonResponse;
    }
}
