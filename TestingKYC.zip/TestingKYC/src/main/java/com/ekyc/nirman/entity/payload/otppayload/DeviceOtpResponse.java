package com.ekyc.nirman.entity.payload.otppayload;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class DeviceOtpResponse {
    private String message ;
}
