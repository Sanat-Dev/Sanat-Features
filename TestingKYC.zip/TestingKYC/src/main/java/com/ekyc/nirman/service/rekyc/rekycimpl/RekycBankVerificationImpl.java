package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.BasicDetailsDao.BankDetailsDao;
import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.payload.innerservice.IfscCodeResponse;
import com.ekyc.nirman.entity.payload.innerservice.RazorPayResponse;
import com.ekyc.nirman.entity.payload.response.RekycCommonResponse;
import com.ekyc.nirman.enums.AccountType;
import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.service.pennydroppayment.PaymentVerificationAndDetails;
import com.ekyc.nirman.service.rekyc.RekycBankVerification;
import io.netty.util.internal.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Slf4j
public class RekycBankVerificationImpl implements RekycBankVerification {

    private final PaymentVerificationAndDetails paymentVerificationAndDetails;
    private final RekycUserRepository rekycUserRepository;
    public RekycBankVerificationImpl(PaymentVerificationAndDetails paymentVerificationAndDetails, RekycUserRepository rekycUserRepository) {
        this.paymentVerificationAndDetails = paymentVerificationAndDetails;
        this.rekycUserRepository = rekycUserRepository;
    }
    public RekycCommonResponse instatiatePennyDropToRekycUserAccountConfirmation(UUID xuserid, BankDetailsDto bankDetailsDto) {
        RekycUserDetailsDao rekycUser =  rekycUserRepository.findById(xuserid).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.UNAUTHORIZED));
        bankDetailsDto.setName(rekycUser.getName());
        String fundId = paymentVerificationAndDetails.createFundAccountOfUser(bankDetailsDto);
        RazorPayResponse razorPayResponse =  paymentVerificationAndDetails.validateBankDetailsOfUserUsingRazorPay(fundId);
        BankDetailsDao bankDetailsDao = new BankDetailsDao();
        bankDetailsDao.setAccountNumber(bankDetailsDto.getAccountNumber());
        bankDetailsDao.setIfsc(bankDetailsDto.getIfsc());
        // adding response from payment of to db object
        bankDetailsDao.setBankRegisteredName(razorPayResponse.getRegisteredName());
        bankDetailsDao.setPennyDropReason(razorPayResponse.getPennyDropReason());
        bankDetailsDao.setStatus(razorPayResponse.getStatus());
        bankDetailsDao.setPayoutId(razorPayResponse.getPayoutId());
        bankDetailsDao.setAccountType(AccountType.SAVING);
        // adding address details from ifsc code
        IfscCodeResponse ifscCodeResponse = paymentVerificationAndDetails.getBankDetailFromIfscCode(bankDetailsDto.getIfsc());
        bankDetailsDao.setBankName(ifscCodeResponse.getName());
        bankDetailsDao.setBranch(ifscCodeResponse.getBranch());
        bankDetailsDao.setAddress(ifscCodeResponse.getAddress());
        bankDetailsDao.setMicr(ifscCodeResponse.getMicr());
        rekycUser.setBankDetailsDao(bankDetailsDao);
        rekycUser.setLockStatus(RekycLockStatus.LOCKED);
        rekycUserRepository.save(rekycUser);
        // different cases for return response of validated user
        // case 1 : if users account number is not valid ones which does not contain a name
        // case 2 : payment get success but bank name doesn't match with our data
        // case 3 : payment is valid and client name is also matched with our records
        if(StringUtil.isNullOrEmpty(razorPayResponse.getRegisteredName())) {
            return RekycCommonResponse.builder().isVerify(false).message("Your account number is Invalid account. kindly upload bank document to verify").build();
        }
        else if(!rekycUser.getName().equals(razorPayResponse.getRegisteredName())) {
            return RekycCommonResponse.builder().isVerify(false).message("Your account number is valid. But Account holder name doesn't match with our records. Kindly upload bank document to verify").build();
        }
        else return RekycCommonResponse.builder().isVerify(true).message("succesfully verified you account.").build();
    }



}
