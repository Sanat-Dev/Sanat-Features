package com.ekyc.nirman.controller;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.payload.SegmentFields;
import com.ekyc.nirman.entity.payload.innerservice.BankProofUploadRequest;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.payload.innerservice.ImageAndSignatureDto;
import com.ekyc.nirman.entity.payload.innerservice.WraperBasicUserInfoAndNomine;
import com.ekyc.nirman.service.UserDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/details")
@Slf4j
public class UserDetailsController {
    private final UserDetailService userDetailService;
    public UserDetailsController(UserDetailService userDetailService) {
        this.userDetailService = userDetailService;
    }
    @PostMapping("/basic-details")
    ResponseEntity<CommonResponse> fillBasicUserDetails(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid WraperBasicUserInfoAndNomine wraperBasicUserInfoAndNomine) {
        this.userDetailService.userNomineeDetails(UUID.fromString(xuserid), wraperBasicUserInfoAndNomine.getListofNomineeMembersInfo());
        return ResponseEntity.ok(this.userDetailService.userBasicDetailsAdd(UUID.fromString(xuserid), wraperBasicUserInfoAndNomine.getBasicUserInfoDto()));
    }

    @PostMapping("/bank-details")
    ResponseEntity<CommonResponse> fillUserBankDetails(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid BankDetailsDto bankDetailsDto) {
        return ResponseEntity.ok(this.userDetailService.bankDetailsAddAndVerify(UUID.fromString(xuserid), bankDetailsDto));
    }

    @PatchMapping("/segment-details")
    ResponseEntity<CommonResponse> fillUserSegmentDetails(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid SegmentFields fields) {
        return ResponseEntity.ok(this.userDetailService.addSegmentDetailsOfUser(UUID.fromString(xuserid), fields));
    }

    @PostMapping("/photo-signature")
    ResponseEntity<CommonResponse> captureInsertImageInDatabase(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid ImageAndSignatureDto imageAndSignatureDto) {
        return ResponseEntity.ok(this.userDetailService.addImageAndSignatureOfUser(UUID.fromString(xuserid), imageAndSignatureDto));
    }

    @PatchMapping("/upload/bank-details")
    ResponseEntity<CommonResponse> captureBankProof(@RequestHeader("xuserid") String xuserid, @RequestBody @Valid BankProofUploadRequest bankProofUploadRequest) {
        return ResponseEntity.ok(this.userDetailService.insertBankProofInDatabase(UUID.fromString(xuserid), bankProofUploadRequest));
    }
}
