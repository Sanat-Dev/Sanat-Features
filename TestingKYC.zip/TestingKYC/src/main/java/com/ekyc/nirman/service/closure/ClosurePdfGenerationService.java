package com.ekyc.nirman.service.closure;

import com.ekyc.nirman.entity.dto.closure.Closure;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.util.DateUtils;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfVersion;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.WriterProperties;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class ClosurePdfGenerationService {
    private final Logger _logger = LoggerFactory.getLogger(ClosurePdfGenerationService.class);
    private final Configuration freeMarkerConfig;
    public ClosurePdfGenerationService(Configuration freeMarkerConfig) {
        this.freeMarkerConfig = freeMarkerConfig;
    }

    public String pdfGenerationRequestForClosureDoc(Closure closure) {
        closure.setDpId("12059500");
        Map<String, String> mp = new HashMap<>();
        String date = DateUtils.getCurrentDateInFormateDDMMYYYYSeparateWithHypen();
        String dataWithout = DateUtils.simpleDateFormatterWithoutSpecialCharacter();
        for(int i =0 ; i < dataWithout.length(); i++) mp.put("date"+String.valueOf(i), String.valueOf(dataWithout.charAt(i)));
        for(int i = 0 ; i < closure.getDpId().length() ; i++) mp.put("client"+String.valueOf(i), String.valueOf(closure.getDpId().charAt(i)));
        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
        String fullDate = dtf2.format(LocalDateTime.now());
        String esignUser = "E-signed by : "+closure.getName()+" <br/>Date : "+fullDate+"<br/>Reason : Account Closing";
        mp.put("fhname", closure.getName());
        mp.put("coradd", closure.getAddress());
        mp.put("corstate", closure.getState());
        mp.put("corcity", closure.getCity());
        for(int i = 0 ; i < closure.getPincode().length() ; i++) mp.put("corpin"+i,String.valueOf(closure.getPincode().charAt(i)));
        mp.put("closingreason", closure.getReasonForClosing());
        mp.put("fhsign", esignUser);
        for(int i =0 ; i < 8 ; i++) mp.put("dpid"+i, "") ;
        if(!Objects.isNull(closure.getNewTransferDpId())) {
            for (int i = 0; i < closure.getNewTransferDpId().length(); i++)
                mp.put("dpid" + i, String.valueOf(closure.getNewTransferDpId().charAt(i)));
        }
        if(!Objects.isNull(closure.getNewTransferClientCode())) {
            int size = 8 - closure.getNewTransferClientCode().length();
            for (int i = 0; i < size; i++) mp.put("clid" + i, "0");
            for (int i = size; i < 8; i++) mp.put("clid" + i, String.valueOf(closure.getNewTransferClientCode().charAt(i - size)));
        } else for (int i = 0; i<8; i++) mp.put("clid" + i, "");

        if(!Objects.isNull(closure.getClientOldDpId())) {
            for (int i = 0; i < closure.getClientOldDpId().length(); i++) mp.put("clientid" + i, String.valueOf(closure.getClientOldDpId().charAt(i)));
        } else for (int i = 0; i<8; i++) mp.put("clientid" + i, "");

        // panno clientcode
        mp.put("panno", closure.getPanNumber());
        mp.put("clientcode", closure.getDpId());
        mp.put("mobileNo", closure.getMobile());
        mp.put("emailId", closure.getEmail());
        mp.put("permanentAddress", closure.getAddress());
        mp.put("permanentCity", closure.getCity());
        mp.put("permanentState", closure.getState());
        mp.put("permanentPincode", closure.getPincode());
        mp.put("date", date);
        StringBuilder closedSegment = new StringBuilder();
        if(closure.isCash()) closedSegment.append("CASH,");
        if(closure.isMcx()) closedSegment.append("MCX,");
        if(closure.isCurrency()) closedSegment.append("CURRENCY,");
        if(closure.isDpCheck()) closedSegment.append("DP,");
        if(closure.isFAndO()) closedSegment.append("FO");
        mp.put("closedSegment", closedSegment.toString());

        if(!Objects.isNull(closure.getNewTransferClientCode())) mp.put("transferred", "checked");
        else mp.put("transferred", "unchecked");
        if(!Objects.isNull(closure.getDpSupportImage()))
            mp.put("dpSupportImage", closure.getDpSupportImage());
        else mp.put("dpSupportImage", "");
        return Base64.getEncoder().encodeToString(ftlFillerForClosureDocs(mp));
    }
    private Template getClosureTemplate() {
        try {
            Template template = freeMarkerConfig.getTemplate("closureNirman.ftl");
            return template;
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    public byte[] ftlFillerForClosureDocs(Map<String, String> model) {
        Template template = getClosureTemplate();
        String html = "";
        try {
            html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
        } catch (Exception e) {
            _logger.info("============  Error -=- error while pdf is empty-");
            throw new BusinessException(ErrorCodes.PDF_FILE_NOT_AVAILIABLE , HttpStatus.BAD_REQUEST);
        }
        if (!html.isEmpty()) {
            return convertHtmlToPdf(html);
        } else {
            _logger.info("============  Error -=- html generation using template, while template seems empty");
            throw new BusinessException(ErrorCodes.PDF_FILE_NOT_AVAILIABLE , HttpStatus.BAD_REQUEST);
        }
    }
    public byte[] convertHtmlToPdf(String htmlString) {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(outputStream, new WriterProperties().setPdfVersion(PdfVersion.PDF_2_0));
            PdfDocument pdfDocument = new PdfDocument(writer);
            pdfDocument.setDefaultPageSize(PageSize.A4);
            pdfDocument.setTagged();
            ConverterProperties converterProperties = new ConverterProperties();
            HtmlConverter.convertToPdf(htmlString, pdfDocument, converterProperties);
            pdfDocument.close();
            byte[] pdfBytes = outputStream.toByteArray();
            return pdfBytes;
        } catch (Exception e) {
            _logger.info("============= Error -=- exception on converting html to pdf");
            throw new BusinessException(ErrorCodes.CANNOT_ABLE_TO_CONVERT_IT, HttpStatus.BAD_REQUEST);
        }
    }

}
