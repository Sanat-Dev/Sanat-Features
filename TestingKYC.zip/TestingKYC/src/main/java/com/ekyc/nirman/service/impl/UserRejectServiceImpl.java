package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.entity.dao.BasicDetailsDao.BankDetailsDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.BasicUserInfoDao;
import com.ekyc.nirman.entity.dao.ImageSignatureDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import com.ekyc.nirman.entity.dto.RejectedDocumentsData;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.enums.RejectDocument;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.*;
import com.ekyc.nirman.service.UserRejectService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class UserRejectServiceImpl implements UserRejectService {

    private final UserDetailMainRepository userDetailMainRepository;
    private final BasicUserDetailsRepository basicUserDetailsRepository;
    private final ImageSignatureRepository imageSignatureRepository;
    private final BankDetailsRepository bankDetailsRepository;
    private final PanCardRepository panCardRepository;
    private final ObjectMapper objectMapper;

    public UserRejectServiceImpl(UserDetailMainRepository userDetailMainRepository, BasicUserDetailsRepository basicUserDetailsRepository, ImageSignatureRepository imageSignatureRepository, BankDetailsRepository bankDetailsRepository, PanCardRepository panCardRepository, ObjectMapper objectMapper) {
        this.userDetailMainRepository = userDetailMainRepository;
        this.basicUserDetailsRepository = basicUserDetailsRepository;
        this.imageSignatureRepository = imageSignatureRepository;
        this.bankDetailsRepository = bankDetailsRepository;
        this.panCardRepository = panCardRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public CommonResponse uploadUserRejectedDocument(UUID userId, RejectedDocumentsData rejectedDocumentsData) {
        UserDetailMainDao users = userDetailMainRepository.findById(userId).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        if(!(KycStatus.REJECTED.equals(users.getKycStatus()))) throw  new BusinessException(ErrorCodes.INPUT_DETAILS_FROM_USERS_SIDE_IS_INVALID, HttpStatus.UNAUTHORIZED);
        if(!Objects.isNull(rejectedDocumentsData.getBankProof())) {
            log.info("-------------- 1");
            if(Objects.isNull(users.getBankDetailId())) {
                throw  new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST);
            }
            log.info("-------------- 1");
            BankDetailsDao bank = bankDetailsRepository.findById(users.getBankDetailId()).orElseThrow(()-> new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
            bank.setBankValidationProof(rejectedDocumentsData.getBankProof());
            bankDetailsRepository.save(bank);
        }
        if(!Objects.isNull(rejectedDocumentsData.getClientImage())) {
            log.info("-------------- 1");
            if(Objects.isNull(users.getImageAndSignatureId())) {
                throw  new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST);
            }
            log.info("-------------- 1");
            ImageSignatureDao imageSignatureDao = imageSignatureRepository.findById(users.getImageAndSignatureId()).orElseThrow(()-> new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
            imageSignatureDao.setImage(rejectedDocumentsData.getClientImage());
            imageSignatureRepository.save(imageSignatureDao);
        }
        if(!Objects.isNull(rejectedDocumentsData.getClientSignature())) {
            log.info("-------------- 1");
            if(Objects.isNull(users.getImageAndSignatureId())) {
                throw  new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST);
            }
            log.info("-------------- 1");
            ImageSignatureDao imageSignatureDao = imageSignatureRepository.findById(users.getImageAndSignatureId()).orElseThrow(()-> new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
            imageSignatureDao.setSignature(rejectedDocumentsData.getClientSignature());
            imageSignatureRepository.save(imageSignatureDao);
        }
        if(!Objects.isNull(rejectedDocumentsData.getFinancialProof())) {
            if(Objects.isNull(users.getBasicUserInformationId())) {
                throw  new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST);
            }
            log.info("-------------- 1");
            BasicUserInfoDao basicUser = basicUserDetailsRepository.findById(users.getBasicUserInformationId()).orElseThrow(()-> new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
            basicUser.setFinancialProofDocument(rejectedDocumentsData.getFinancialProof());
            basicUserDetailsRepository.save(basicUser);
        }
        if(!Objects.isNull(rejectedDocumentsData.getPanCard())) {
            if(Objects.isNull(users.getPanCardId())) {
                throw  new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST);
            }
            log.info("-------------- 1");
            PanCardDao pan = panCardRepository.findById(users.getPanCardId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_DETAILS_ARE_NOT_FOUND, HttpStatus.BAD_REQUEST));
            pan.setPan_pdf(Base64.getDecoder().decode(rejectedDocumentsData.getPanCard()));
            log.info("-------------- 1");
            panCardRepository.save(pan);
        }
        users.setKycStatus(KycStatus.THANK_YOU);
        userDetailMainRepository.save(users);
        return CommonResponse.builder().message("Succesfully Uploaded Document").kycStatus(KycStatus.THANK_YOU).build();
    }
    @Override
    public List<String> userRejectedListDocs(UUID userId) {
        UserDetailMainDao user = userDetailMainRepository.findById(userId).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        List<String> rejectDocuments =  Arrays.asList(user.getRejecetdDocsCommaSeprated().split(","));
        return rejectDocuments;
    }

}
