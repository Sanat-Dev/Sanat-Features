package com.ekyc.nirman.entity.dao.BasicDetailsDao;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Data
@Entity
@Table(name = "basic_user_detail")
public class BasicUserInfoDao {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator", parameters = {
            @org.hibernate.annotations.Parameter(name = "UUID_gen_strategy_class", value = "org.hibernate.id.UUID.CustomVersionOneStrategy") })
    @Column(name = "id" , columnDefinition = "BINARY(16)")
    private UUID id;
    @Column(name = "martial_status", length = 15)
    private String maritalStatus ;
    @Column(name = "spouse_name", length = 50)
    private String spouseName ;
    @Column(name = "mother_name", length = 50)
    private String motherName ;
    @Column(name= "father_name", length = 50)
    private String fatherName ;
    @Column(name = "education" , length = 20)
    private String education;
    @Column(name = "trading_experience", length = 4)
    private String tradingExperience ;
    @Column(name = "occupation", length = 20)
    private String occupation ;
    @Column(name = "nominee_check", length = 15)
    private String nomineeCheck ;
    @Column(name = "tax_residance", length = 20)
    private String taxResidence ;
    @Column(name = "net_worth", length = 20)
    private String netWorth ;
    @Column(name = "annual_salary", length = 4)
    private String annualSalary;
    @Column(name = "politically_exposed", length = 10)
    private String politicallyExposed ;
    @Column(name = "nse_cash")
    private boolean nseCash ;
    @Column(name = "nse_future_and_option")
    private boolean nseFutureAndOption ;
    @Column(name = "nse_cds")
    private boolean bseCds ;
    @Column(name = "nse_mcx")
    private boolean bseCash ;
    @Column(name = "bse_future_And_option")
    private boolean bseFutureAndOption;
    @Column(name = "is_ddpi_opted")
    private boolean isDDPIOpted;
    @Column(name = "nationality",length = 15)
    private String nationality ;
    @Column(name = "brokerage_amount", length = 10)
    private String brokerageAmount;
    @Column(name = "action_taken_by_sebi", length = 20)
    private String actionTakenBySebiOrAnyOtherAuthority ;
    @Column(name = "action_taken_by_sebi_description", length = 40)
    private String actionTakenBySebiOrAnyOtherAuthorityDescription ;
    @Lob
    @Column(name = "financial_proof_document")
    private String financialProofDocument ;
    @Column(name = "rejected_documents", length = 80)
    private String rejectedDocument;
}
