package com.ekyc.nirman.entity.dao.rekyc;
import com.ekyc.nirman.entity.dao.AadharDataDao;
import com.ekyc.nirman.entity.dao.BaseDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.BankDetailsDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.NomineeDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.SubscriptionList;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.enums.RekycStatus;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.w3c.dom.stylesheets.LinkStyle;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "rekyc_users")
public class RekycUserDetailsDao extends BaseDao {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator", parameters = {
            @org.hibernate.annotations.Parameter(name = "UUID_gen_strategy_class", value = "org.hibernate.id.UUID.CustomVersionOneStrategy") })
    @Column(name = "id", columnDefinition = "BINARY(16)")
    private UUID id;
    @Column(name = "client_code")
    private String clientCode ;
    private String mobile;
    private String name;
    private String email;
    @Column(name="new_mobile")
    private String newMobile;
    @Column(name = "new_email")
    private String newEmail;
    @Column(name = "pan_number")
    private String panNumber;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "bank_detail_fk")
    private BankDetailsDao bankDetailsDao;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "aadhar_fk_id")
    private AadharDataDao aadharDataDao;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "pan_card_fk")
    private PanCardDao panCardDao;
    @Column(name = "lock_status")
    @Enumerated(EnumType.STRING)
    private RekycLockStatus lockStatus;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "nominee_fk_id", referencedColumnName = "id")
    private List<NomineeDao> nomineeDao;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "rekyc_fk_id")
    private RekycAdditionalDetailsDao rekycAdditionalDetailsDao;
    @Column(name = "rekyc_status")
    @Enumerated(EnumType.STRING)
    private RekycStatus rekycStatus;
    @Column(name = "rejected_docs")
    private String rejecetdDocsCommaSeprated;
    @Column(name = "new_segment_selection")
    private String newSegmentSelectionCommaSeprated;
    @Column(name = "leegality_docs_id")
    private String leegalityDocsId;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "subscription_list")
    private SubscriptionList subscriptionList;
//    segment , addhar , pan, address , status , lockedStatus
}
