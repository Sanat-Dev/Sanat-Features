package com.ekyc.nirman.service;

public interface SFTPService {
     String uploadToSFTPFiles(String fromPath);
}
