package com.ekyc.nirman.service.rekyc;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.payload.response.RekycCommonResponse;

import java.util.UUID;

public interface RekycBankVerification {
    RekycCommonResponse instatiatePennyDropToRekycUserAccountConfirmation(UUID xuserid, BankDetailsDto bankDetailsDto);

}
