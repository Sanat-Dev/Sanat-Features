package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import com.ekyc.nirman.entity.dao.closure.ClosureDB;
import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.payload.response.PdfFile;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.repository.ClosureDBRepository;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.repository.UserDetailMainRepository;
import com.ekyc.nirman.service.LegalityService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class LegalityServiceImpl implements LegalityService {
    @Autowired
    TenantConstants tenantConstants;

    private String leegalityAuthToken = tenantConstants.LEEGALITY_AUTH_TOKEN;
    private String leegalityRedirectUrl = tenantConstants.CLOSURE_LEEGALITY_CALLBACK_URL;

    private OkHttpClient client = new OkHttpClient();
    private final ObjectMapper objectMapper ;
    private final UserDetailMainRepository userDetailMainRepository ;
    private final RekycUserRepository rekycUserRepository;
    private final ClosureDBRepository closureDBRepository;

    public LegalityServiceImpl(ObjectMapper objectMapper, UserDetailMainRepository userDetailMainRepository, RekycUserRepository rekycUserRepository,ClosureDBRepository closureDBRepository) {
        this.objectMapper = objectMapper;
        this.userDetailMainRepository = userDetailMainRepository;
        this.rekycUserRepository = rekycUserRepository;
        this.closureDBRepository =  closureDBRepository;
    }

    @Override
    public CommonResponse esignPdfusingLegality(PdfFile pdfFile){
        String payload = "{\"file\":{\"name\":\"Re_" + pdfFile.getPanCard() + "\",\"file\":\"" + pdfFile.getPdf() + "\"},\"invitees\":[{\"name\":\"" + pdfFile.getName() + "\",\"email\":\"" + pdfFile.getEmail() + "\",\"phone\":\"" + pdfFile.getMobile() + "\",\"emailNotification\":\"true\",\"phoneNotification\":\"false\",\"webhook\":{\"success\":\""+leegalityRedirectUrl+"\",\"failure\":\""+leegalityRedirectUrl+"\",\"version\":\"2.3\"},\"redirectUrl\":\""+leegalityRedirectUrl+"\",\"signatures\":[{\"type\":\"AADHAAR\",\"config\":{\"authTypes\":[\"OTP\",\"BIO\",\"IRIS\"]}}]}],\"irn\":\"" + pdfFile.getPanCard() + "/RE\"}";
        Request request = new Request.Builder()
                .url("https://app1.leegality.com/api/v2.1/sign/request")
                .addHeader("Content-Type" ,"application/json")
                .addHeader("X-Auth-Token", leegalityAuthToken)
                .post(RequestBody.create(MediaType.parse("application/json"), payload))
                .build();
        Call call = client.newCall(request);
        Response response = null ;
        String jsonResponse = null;
        try{
            response = call.execute();
            jsonResponse = response.body().string();
        }
        catch (Exception e){
            System.out.println(" i  am an Exception");
        }
        try {
            JsonNode rootNode = objectMapper.readTree(jsonResponse);
            JsonNode dataNode = rootNode.get("data");
            String documentId = dataNode.get("documentId").asText();
            JsonNode invitationsNode = dataNode.get("invitations");
            String signUrl = invitationsNode.get(0).get("signUrl").asText();
            System.out.println("------------------------------- Document ID: " + documentId);
            System.out.println("------------------------------- Sign URL: " + signUrl);
            Optional<UserDetailMainDao> user = userDetailMainRepository.findByPhoneNumber(pdfFile.getMobile());
            if(user.isEmpty()) {
                throw new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST);
            }
            user.get().setDocumentId(documentId);
            user.get().setKycStatus(KycStatus.THANK_YOU);
            userDetailMainRepository.save(user.get());
            return CommonResponse.builder()
                    .kycStatus(KycStatus.E_SIGN)
                    .message(signUrl).build();
        }catch (Exception e){
            System.out.println("--------------------  Exception is here");
            throw new BusinessException(ErrorCodes.E_SIGN_NOT_WORKED, HttpStatus.BAD_REQUEST);
        }
    }
    public CommonResponse saveEsignDocumetId(UUID xuserid, String documentId) {
        UserDetailMainDao user = (UserDetailMainDao)this.userDetailMainRepository.findById(xuserid).orElseThrow(() -> {
            throw new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST);
        });
        Request request = new Request.Builder()
                .url("https://app1.leegality.com/api/v2.1/sign/request?documentId="+documentId)
                .addHeader("Content-Type" ,"application/json")
                .addHeader("X-Auth-Token", leegalityAuthToken)
                .get()
                .build();
        Call call = client.newCall(request);
        Response response = null ;
        String jsonResponse = null;
        try{
            response = call.execute();
            jsonResponse = response.body().string();
        }
        catch (Exception e){
            System.out.println(" i  am an Exception");
        }
        String auditTrail = null;
        String fileValue = null ;
        try {
            JsonNode jsonNode = objectMapper.readTree(jsonResponse);;
            auditTrail = jsonNode.path("data").get("auditTrail").asText();
            JsonNode filesArray = jsonNode.path("data").get("files");
            log.info("----------------------- files array data {}", filesArray.size());
            if (filesArray != null && filesArray.isArray() && filesArray.size() == 1) {
                fileValue = filesArray.get(0).asText();
            }
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.E_SIGN_NOT_WORKED , HttpStatus.BAD_REQUEST);
        }
        user.setAuditTrail(auditTrail);
        user.setESignedPdf(fileValue);
        user.setKycStatus(KycStatus.USER_PROCESS_COMPLETED);
        userDetailMainRepository.save(user);
        return CommonResponse.builder().message("Id successfull uploaded").kycStatus(KycStatus.USER_PROCESS_COMPLETED).build();
    }

    public String saveEsignDocumentInDatabase(String phoneNumber, String documentId, String isrekyc) {
        switch(isrekyc) {
            case "KYC":
                return saveEsignDocumentIdOfKycUserInkycDB(phoneNumber, documentId);
            case "REKYC":
                return saveEsignDocumentIdOfReKycUserInReKycDB(phoneNumber, documentId);
            case "CLOSURE":
                return saveEsignDocumentIdOfClosureUserInClosureDB(phoneNumber, documentId);
            default:
                return "Failed to store in DB.";
        }

    }

    public String saveEsignDocumentIdOfClosureUserInClosureDB(String phoneNumber, String docId) {
        ClosureDB closureDB = closureDBRepository.findByPhoneNumber(phoneNumber).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        closureDB.setLeegalityDocsId(docId);
        closureDB.setClosureStatus("CLOSURE");
        closureDBRepository.save(closureDB);
        return "successfully uploaded details";
    }

    public String saveEsignDocumentIdOfKycUserInkycDB(String phoneNumber, String docId) {
        UserDetailMainDao userDetailDB = userDetailMainRepository.findByPhoneNumber(phoneNumber).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        userDetailDB.setDocumentId(docId);
        userDetailDB.setKycStatus(KycStatus.USER_PROCESS_COMPLETED);
        userDetailMainRepository.save(userDetailDB);
        return "successfully uploaded details";
    }

    public String saveEsignDocumentIdOfReKycUserInReKycDB(String phoneNumber, String docId) {
        RekycUserDetailsDao rekycDB = rekycUserRepository.findByMobile(phoneNumber).orElseThrow(()-> new BusinessException(ErrorCodes.REKYC_USER_DETAILS_NOT_EXIST, HttpStatus.BAD_REQUEST));
        rekycDB.setRekycStatus(RekycStatus.ESIGNED);
        rekycDB.setLeegalityDocsId(docId);
        rekycUserRepository.save(rekycDB);
        return "successfully uploaded details";
    }
}
