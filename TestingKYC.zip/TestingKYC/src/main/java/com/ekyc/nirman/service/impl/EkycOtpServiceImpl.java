package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.payload.otppayload.*;
import com.ekyc.nirman.entity.payload.response.EmailResponse;
import com.ekyc.nirman.entity.payload.otppayload.MobileOtpResponse;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.repository.UserDetailMainRepository;
import com.ekyc.nirman.service.EkycOtpService;
import com.ekyc.nirman.service.otpservicehelper.GenericOtpService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
public class EkycOtpServiceImpl implements EkycOtpService {
    private final Logger _logger = LoggerFactory.getLogger(EkycOtpServiceImpl.class);
//    @Resource(name = "redisTemplate")
//    private HashOperations<String,String, OtpInRedis> hashOperations;
    private final UserDetailMainRepository userDetailMainRepository;
//    private final ObjectMapper objectMapper;
    private final GenericOtpService genericOtpService;
//    OkHttpClient client = new OkHttpClient();

    @Autowired
    TenantConstants tenantConstants;

    private String baseUrl = tenantConstants.NOTIFICATION_SERVICE_URL ;

    public EkycOtpServiceImpl(UserDetailMainRepository userDetailMainRepository, GenericOtpService genericOtpService) {
        this.userDetailMainRepository = userDetailMainRepository;
        this.genericOtpService = genericOtpService;
    }
//    @Async
//    @Override
//    public DeviceOtpResponse sendOtpToUser(DeviceOtpRequest deviceOtpRequest, NotificationType notificationType) {
//        Map<String, String> requestModel = new HashMap<>();
//        requestModel.put("name", deviceOtpRequest.getValue());
//        String otp = genericOtpService.generateOtpForDevice();
//        requestModel.put("otp", otp);
//        switch (notificationType) {
//            case SMS:
//                genericOtpService.saveOtpInRedisCacheMemory(deviceOtpRequest.getValue(), otp, 3);
//                break;
//            case EMAIL:
//                genericOtpService.saveOtpInRedisCacheMemory(deviceOtpRequest.getValue(), otp, 5);
//                break;
//        }
//        log.info("----------------- user otp details to send {} " , requestModel);
//        genericOtpService.sendOtpToUser(deviceOtpRequest.getValue(), notificationType, requestModel);
//        return new DeviceOtpResponse("otp sent successfully") ;
//    }
    @Async
    @Override
    public DeviceOtpResponse sendOtpToUser(DeviceOtpRequest deviceOtpRequest, NotificationType notificationType) {
        String otp = genericOtpService.generateOtpForDevice();
        genericOtpService.saveOtpInRedisCacheMemory(deviceOtpRequest.getValue(),otp,5);
        genericOtpService.sendOtpToUser(deviceOtpRequest.getValue(), notificationType, Map.of("name", "", "otp", otp));
        return new DeviceOtpResponse("otp sent successfully") ;
    }
//    @Override
//    public MobileOtpResponse verifyMobileOtp(MobileOtpRequest mobileOtpRequest) {
//        OtpInRedis otpVerification = hashOperations.get("OtpInRedis",mobileOtpRequest.getPhone());
//        if(otpVerification == null){
//            throw new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.UNAUTHORIZED);
//        }
//        log.info("-------------------------------otp verification details {}", otpVerification);
//        if(otpVerification.getOtp().equals(mobileOtpRequest.getOtp()) && otpVerification.getExpiryTimeStamp() >= System.currentTimeMillis()){
//            return savePhoneNumberInDatabase(mobileOtpRequest.getPhone());
//        }
//        return MobileOtpResponse.builder().message("Your otp is invalid").userid(null).kycStatus(KycStatus.LOGIN).build();
//    }
    @Override
    public MobileOtpResponse verifyMobileOtp(MobileOtpRequest mobileOtpRequest, String rmname) {
        _logger.info("----------------------- otp request {}", mobileOtpRequest);
        OtpVerificationResponse otpVerification = genericOtpService.verifyOtpOfUser(mobileOtpRequest.getPhone(), mobileOtpRequest.getOtp());
        _logger.info("----------------otp verification request {}" , otpVerification.toString());
        if(otpVerification.isVerified()) {
            return savePhoneNumberInDatabase(mobileOtpRequest.getPhone(), rmname);
        }
        return MobileOtpResponse.builder().message("Your otp is invalid").userid(null).kycStatus(KycStatus.LOGIN).build();
    }

//    @Override
//    public EmailResponse verifyEmailOtp(UUID xuserid , EmailOtpRequest emailOtpRequest) {
//        Optional<UserDetailMainDao> userDetail = userDetailMainRepository.findById(xuserid);
//        OtpInRedis otpVerification = hashOperations.get("OtpInRedis",emailOtpRequest.getEmail());
//        if(otpVerification == null || userDetail.isEmpty()){
//            throw new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST);
//        }
//        log.info("-------------------------------otp verification details {}", otpVerification);
//        // otp validation using exact otp
//        if(otpVerification.getOtp().equals(emailOtpRequest.getOtp()) && otpVerification.getExpiryTimeStamp() >= System.currentTimeMillis()){
//            return this.userEmailSaver(xuserid, emailOtpRequest.getEmail());
//        }
//        return EmailResponse.builder().message("otp is incorrect").kycStatus(KycStatus.LOGIN).build();
//    }
    @Override
    public EmailResponse verifyEmailOtp(UUID xuserid , EmailOtpRequest emailOtpRequest) {
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.UNAUTHORIZED));
        OtpVerificationResponse response = genericOtpService.verifyOtpOfUser(emailOtpRequest.getEmail(),emailOtpRequest.getOtp());
        if(response.isVerified()) {
            return this.userEmailSaver(xuserid, emailOtpRequest.getEmail());
        }
        return EmailResponse.builder().message("otp is incorrect").kycStatus(KycStatus.LOGIN).build();
    }
    public EmailResponse userEmailSaver(UUID xuserid, String email) {
        UserDetailMainDao userDetails = this.userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        userDetails.setEmail(email);
        userDetails.setKycStatus(KycStatus.DIGILOCKER);
        try {
            this.userDetailMainRepository.save(userDetails);
        } catch (Exception e) {
            // current email is already exist
            _logger.info("=========ERROR -=- EMIAL already exist of user {}", email);
            throw new BusinessException(ErrorCodes.EMAIL_ALREADY_EXIST, HttpStatus.UNPROCESSABLE_ENTITY);
        }
        return EmailResponse.builder().message("otp is correct").kycStatus(KycStatus.DIGILOCKER).build();
    }

    public MobileOtpResponse savePhoneNumberInDatabase(String phoneNumber, String rmname) {
        System.out.println(" -------------------------- i am saving details" + phoneNumber);
        Optional<UserDetailMainDao> user = this.userDetailMainRepository.findByPhoneNumber(phoneNumber);
        if (user.isPresent()) {
            return MobileOtpResponse.builder().message("otp verified").userid(String.valueOf((user.get()).getId())).kycStatus(user.get().getKycStatus()).build();
        } else {
            _logger.info("---------------------  user is not persent creating new user ----------");
            UserDetailMainDao newUser  = new UserDetailMainDao();
            newUser.setPhoneNumber(phoneNumber);
            if(!Objects.isNull(rmname)) newUser.setRmname(rmname);
            newUser.setKycStatus(KycStatus.LOGIN);
            newUser = this.userDetailMainRepository.save(newUser);
            return MobileOtpResponse.builder().message("otp verified").userid(String.valueOf(newUser.getId())).kycStatus(KycStatus.LOGIN).build();
        }
    }
}

