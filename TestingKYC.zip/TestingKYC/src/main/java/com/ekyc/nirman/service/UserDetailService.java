package com.ekyc.nirman.service;


import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.BasicUserInfoDto;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.ListofNomineeMembersInfo;
import com.ekyc.nirman.entity.payload.SegmentFields;
import com.ekyc.nirman.entity.payload.innerservice.BankProofUploadRequest;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.payload.innerservice.ImageAndSignatureDto;
import java.util.UUID;

public interface UserDetailService {
    void userNomineeDetails(UUID xuserid, ListofNomineeMembersInfo listofBasicUserInfo);
    CommonResponse userBasicDetailsAdd(UUID xuserid, BasicUserInfoDto basicUserInfoDto);
    CommonResponse bankDetailsAddAndVerify(UUID xuserid, BankDetailsDto bankDetailsDto);
    CommonResponse addSegmentDetailsOfUser(UUID xuserid, SegmentFields fields);
    CommonResponse addImageAndSignatureOfUser(UUID xuserid, ImageAndSignatureDto imageAndSignatureDto);
    CommonResponse insertBankProofInDatabase(UUID xuserid, BankProofUploadRequest bankProofUploadRequest);
}
