package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.service.rekyc.RekycBankVerification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.UUID;

@Controller
@RequestMapping("api/v1/rekyc/bank")
public class RekycUserBankAdditionController {

    private final RekycBankVerification rekycBankVerification;

    public RekycUserBankAdditionController(RekycBankVerification rekycBankVerification) {
        this.rekycBankVerification = rekycBankVerification;
    }
    @PostMapping("/add")
    public ResponseEntity<?> addRekycUserAccountToDatabase(@RequestHeader("xuserid") UUID xuserid, @Valid @RequestBody BankDetailsDto bankDetailsDto) {
        return ResponseEntity.ok(rekycBankVerification.instatiatePennyDropToRekycUserAccountConfirmation(xuserid, bankDetailsDto));
    }
}
