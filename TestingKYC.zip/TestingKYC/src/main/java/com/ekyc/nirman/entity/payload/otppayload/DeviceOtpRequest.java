package com.ekyc.nirman.entity.payload.otppayload;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class DeviceOtpRequest {
    @NotNull(message = "required field should be present")
    @NotBlank(message = "field value should be greater then 0")
    private String value ;
}
