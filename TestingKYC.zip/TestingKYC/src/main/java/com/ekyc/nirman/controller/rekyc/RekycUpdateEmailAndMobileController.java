package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationRequest;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.service.rekyc.RekycUserUpdateMobileAndEmail;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@Controller
@RequestMapping("/api/v1/rekyc/update")
public class RekycUpdateEmailAndMobileController {
    private final RekycUserUpdateMobileAndEmail rekycUserUpdateMobileAndEmail;
    public RekycUpdateEmailAndMobileController(RekycUserUpdateMobileAndEmail rekycUserUpdateMobileAndEmail) {
        this.rekycUserUpdateMobileAndEmail = rekycUserUpdateMobileAndEmail;
    }
    @PostMapping("/send")
    public ResponseEntity<?> sendOtpToUsersDevice(@RequestHeader("xuserid") String xuserid, @RequestParam("type") NotificationType notificationType, @RequestBody @Valid DeviceOtpRequest deviceOtpRequest) {
        return ResponseEntity.ok(rekycUserUpdateMobileAndEmail.sendOtpToUserRequestedDevice(notificationType, deviceOtpRequest));
    }
    @PostMapping("otp/verify")
    public ResponseEntity<OtpVerificationResponse> verifyUserRequestedOtpAndDevice(@RequestHeader("xuserid") UUID xuserid, @RequestParam("type") NotificationType notificationType, @RequestBody @Valid OtpVerificationRequest otpVerificationRequest) {
        System.out.println("-----------------value"+xuserid);
        return ResponseEntity.ok(rekycUserUpdateMobileAndEmail.verifyAndUpdateUserRequestedDeviceDetails(xuserid, notificationType, otpVerificationRequest));
    }
}
