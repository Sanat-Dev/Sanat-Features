package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.dto.rekyc.RekycCommonResponse;
import com.ekyc.nirman.entity.rekyc.RekycSubmitDetails;
import com.ekyc.nirman.service.rekyc.RekycUserOtherDetailsSubmitService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/submit")
public class RekycSubmitController {
    private final RekycUserOtherDetailsSubmitService rekycUserOtherDetailsSubmitService;
    public RekycSubmitController(RekycUserOtherDetailsSubmitService rekycUserOtherDetailsSubmitService) {
        this.rekycUserOtherDetailsSubmitService = rekycUserOtherDetailsSubmitService;
    }
    @PostMapping("user/details")
    public ResponseEntity<RekycCommonResponse> addUsersSubmitDetails(@RequestHeader("xuserid") UUID xuserid, @RequestBody RekycSubmitDetails rekycSubmitDetails) {
        return ResponseEntity.ok(rekycUserOtherDetailsSubmitService.addAdditionalUserDetails(xuserid, rekycSubmitDetails));
    }
    @GetMapping("/esign/{esignId}")
    ResponseEntity<?> saveEsignPdfDocument(@RequestHeader("xuserid") String xuserid,  @PathVariable(name = "esignId") String esignId) {
        return ResponseEntity.ok(this.rekycUserOtherDetailsSubmitService.submitEsignUrlUpload(UUID.fromString(xuserid), esignId));
    }
}
