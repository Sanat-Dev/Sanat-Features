package com.ekyc.nirman.service.rekyc;

public interface RekycBackOfficeDataApi {
    String backOfficeApiDataUsingDpid(String DpId);
}
