package com.ekyc.nirman.entity.dto.otpResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;


@Builder
@AllArgsConstructor
@Getter
public class OtpVerificationResponse {
    private boolean isVerified;
    private String message ;
}
