package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.entity.payload.response.PdfFile;

import java.util.UUID;

public interface LegalityService {
    CommonResponse esignPdfusingLegality(PdfFile pdfFile);
    CommonResponse saveEsignDocumetId(UUID xuserid, String documentId);
    String saveEsignDocumentInDatabase(String phoneNumber, String documentId, String isrekyc);
}
