package com.ekyc.nirman.entity.payload.innerservice;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AadharResponseData {
    private String aadharProfilePhotoBase64;
    private String name;
    private String careOf;
    private String dob;
    private String maskAadharNumber;
}
