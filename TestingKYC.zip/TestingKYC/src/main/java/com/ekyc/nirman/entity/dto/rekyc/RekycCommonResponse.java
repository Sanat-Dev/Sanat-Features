package com.ekyc.nirman.entity.dto.rekyc;

import com.ekyc.nirman.enums.RekycStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RekycCommonResponse {
    private String message;
    private RekycStatus rekycStatus;
}
