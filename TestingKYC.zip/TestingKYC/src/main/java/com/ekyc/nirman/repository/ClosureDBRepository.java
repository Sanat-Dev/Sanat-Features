package com.ekyc.nirman.repository;

import com.ekyc.nirman.entity.dao.closure.ClosureDB;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ClosureDBRepository extends JpaRepository<ClosureDB, UUID> {
    Optional<ClosureDB> findByPhoneNumber(String phoneNumber);
    Optional<ClosureDB> findByDpId(String clientCode);
    Optional<ClosureDB> findByPhoneNumberAndClosureStatusNot(String phoneNumber, String closureStatus);
}
