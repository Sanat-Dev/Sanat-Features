package com.ekyc.nirman.MultitenantConfig;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Properties;

@Service
public class TenantPropertiesConfig {

    public Properties getTenantProperties(String tenantId){
        try {

            ClassPathResource resource = new ClassPathResource("/allTenants/"+tenantId+".properties");
            return PropertiesLoaderUtils.loadProperties(resource);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load tenant properties file for " + tenantId, e);
        }
    }

    public String getNotificationUrl(String tenantId){
        return getTenantProperties(tenantId).getProperty("notification.service.url");
    }

    public String getBackOfficeUrl(String tenantId){
        return getTenantProperties(tenantId).getProperty("back.office.url");
    }

    public String getEkycClientCode(String tenantId){
        return getTenantProperties(tenantId).getProperty("ekyc.client.code");
    }

    public String getDigiLockerClientId(String tenantId){
        return getTenantProperties(tenantId).getProperty("digi.locker.client.id");
    }

    public String getDigiLockerClientSecret(String tenantId){
        return getTenantProperties(tenantId).getProperty("digi.locker.client.secret");
    }

    public String getDigiLockerRedirectUri(String tenantId){
        return getTenantProperties(tenantId).getProperty("digi.locker.client.redirect.uri");
    }

    public String getDigiLockerRekycClientId(String tenantId){
        return getTenantProperties(tenantId).getProperty("digilocker.rekyc.client.id");
    }

    public String getDigiLockerRekycClientSecret(String tenantId){
        return getTenantProperties(tenantId).getProperty("digilocker.rekyc.client.secret");
    }

    public String getDigiLockerRekycRedirectUri(String tenantId){
        return getTenantProperties(tenantId).getProperty("digilocker.rekyc.client.redirect.uri");
    }

    public String getRazorpayFundClientContactId(String tenantId){
        return getTenantProperties(tenantId).getProperty("rajorpay.fund.client.contact.id");
    }

    public String getRazorpayFundClientAuthUsername(String tenantId){
        return getTenantProperties(tenantId).getProperty("rajorpay.fund.client.auth.username");
    }

    public String getRazorpayFundClientAuthUserpassword(String tenantId){
        return getTenantProperties(tenantId).getProperty("rajorpay.fund.client.auth.userpassword");
    }

    public String getRazorpayFundClientAccountNo(String tenantId){
        return getTenantProperties(tenantId).getProperty("rajorpay.fund.client.account.no");
    }

    public String getClosureLeegalityCallbackUrl(String tenantId){
        return getTenantProperties(tenantId).getProperty("closure.leegality.callback.url");
    }

    public String getLeegalityOrgUrl(String tenantId){
        return getTenantProperties(tenantId).getProperty("leegality.org.url");
    }

    public String getLeegalityAuthToken(String tenantId){
        return getTenantProperties(tenantId).getProperty("leegality.auth.token");
    }

    public String getSftpNirmanUsername(String tenantId){
        return getTenantProperties(tenantId).getProperty("sftp.cvlkra.username");
    }

    public String getSftpNirmanPassword(String tenantId){
        return getTenantProperties(tenantId).getProperty("sftp.cvlkra.password");
    }
}
