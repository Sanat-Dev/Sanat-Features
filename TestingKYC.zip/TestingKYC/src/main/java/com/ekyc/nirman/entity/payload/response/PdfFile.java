package com.ekyc.nirman.entity.payload.response;

import lombok.Data;

@Data
public class PdfFile {
    String pdf ;
    String panCard ;
    String name ;
    String email ;
    String mobile ;
}
