package com.ekyc.nirman.controller.rekyc;

import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.dto.otpResponse.RekycOtpVerificationRequest;
import com.ekyc.nirman.entity.dto.rekyc.RekycBackOfficeUserDetails;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.service.rekyc.ReKycUserVerification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Objects;


@RestController
@RequestMapping("api/v1/rekyc")
public class RekycOtpController {
    private final ReKycUserVerification reKycUserVerification;
    public RekycOtpController(ReKycUserVerification reKycUserVerification) {
        this.reKycUserVerification = reKycUserVerification;
    }
    @PostMapping("/send/otp")
    ResponseEntity<?> sendOtpToUser(@Valid @RequestBody DeviceOtpRequest deviceOtpRequest) {
        return ResponseEntity.ok(reKycUserVerification.userVerificationCodeSender(deviceOtpRequest.getValue()));
    }
    @PostMapping("/verify/otp")
    public ResponseEntity<?> verifyMobileOtpOfUser(@Valid @RequestBody RekycOtpVerificationRequest rekycOtpVerificationRequest) {
        System.out.println("-------------- data value " + rekycOtpVerificationRequest);
        RekycBackOfficeUserDetails rekycDetails = reKycUserVerification.userVerficationUsingOtp(rekycOtpVerificationRequest.getDpId(), rekycOtpVerificationRequest.getOtp());
        return (Objects.isNull(rekycDetails))? new ResponseEntity<>(OtpVerificationResponse.builder().message("invalid credential").build() , HttpStatus.BAD_REQUEST): ResponseEntity.ok(rekycDetails);
    }
}

