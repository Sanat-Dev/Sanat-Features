package com.ekyc.nirman.util;

import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.exception.BusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class StringToJsonConverter {
    public <T> T convertJsonStringToObjectType(String jsonString, Class<T> clazz) {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.readValue(jsonString, clazz);
        }
        catch (JsonMappingException e) {
            throw new BusinessException(ErrorCodes.JSON_NOT_CONVERTED, HttpStatus.BAD_REQUEST);
        } catch (JsonProcessingException e) {
            throw new BusinessException(ErrorCodes.DIGI_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST);
        }
        catch (Exception e){
            throw new BusinessException(HttpStatus.BAD_REQUEST);
        }
    }
}
