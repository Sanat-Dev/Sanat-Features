package com.ekyc.nirman.entity.dto.otpResponse;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class RekycOtpVerificationRequest {
    @NotNull(message = "dpId can not be empty")
    private String dpId;
    @NotNull(message = "otp value should not be empty")
    private String otp;
}
