package com.ekyc.nirman.controller;

import com.ekyc.nirman.entity.dto.RejectedDocumentsData;
import com.ekyc.nirman.enums.RejectDocument;
import com.ekyc.nirman.service.UserRejectService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("api/v1/rejected")
public class UserRejectController {
    private final UserRejectService userRejectService;
    public UserRejectController(UserRejectService userRejectService) {
        this.userRejectService = userRejectService;
    }
    @PostMapping("/document/upload")
    public ResponseEntity<?> uploadRejectedDocuments(@RequestHeader("xuserid") String xuserid, @RequestBody RejectedDocumentsData rejectedDocumentsData) {
        return ResponseEntity.ok(userRejectService.uploadUserRejectedDocument(UUID.fromString(xuserid) , rejectedDocumentsData));
    }
    @GetMapping("/user/list")
    public ResponseEntity<List<String>> getUserRejectedList(@RequestHeader("xuserid") UUID xuserid) {
        return ResponseEntity.ok(userRejectService.userRejectedListDocs(xuserid));
    }
}
