package com.ekyc.nirman.service.closure;


import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.MultitenantConfig.TenantPropertiesConfig;
import com.ekyc.nirman.entity.dao.closure.ClosureDB;
import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.SuccessResponse;
import com.ekyc.nirman.entity.dto.closure.Closure;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.dto.rekyc.RekycBackOfficeUserDetails;
import com.ekyc.nirman.entity.dto.rekyc.RekycBankDetails;
import com.ekyc.nirman.entity.payload.response.PdfFile;
import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.ClosureDBRepository;
import com.ekyc.nirman.service.otpservicehelper.GenericOtpService;
import com.ekyc.nirman.service.rekyc.RekycBackOfficeDataApi;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

@Service
public class ClosureService {
    @Autowired
    TenantPropertiesConfig tenantPropertiesConfig;

    private final Logger _logger = LoggerFactory.getLogger(ClosureService.class);
    private final ClosurePdfGenerationService closurePdfGenerationService;
    private final RekycBackOfficeDataApi backOfficeDataApi;
    private final GenericOtpService otpService;
    private final ObjectMapper objectMapper;
    private final String leegalityRedirectUrl;
    private final String leegalityOrgURl;
    private final String leegalityAuthToken;
    private final ClosureDBRepository closureDBRepository;
    private final OkHttpClient client;
    public ClosureService(ClosurePdfGenerationService closurePdfGenerationService, RekycBackOfficeDataApi backOfficeDataApi, GenericOtpService otpService, OkHttpClient client, ObjectMapper objectMapper, ClosureDBRepository closureDBRepository, final String leegalityRedirectUrl, final String leegalityOrgUrl, final String leegalityAuthToken) {
        this.backOfficeDataApi = backOfficeDataApi;
        this.otpService = otpService;
        this.objectMapper = objectMapper;
        this.closureDBRepository = closureDBRepository;
        this.leegalityRedirectUrl = tenantPropertiesConfig.getClosureLeegalityCallbackUrl();
        this.leegalityOrgURl = tenantPropertiesConfig.getLeegalityOrgUrl();
        this.leegalityAuthToken = tenantPropertiesConfig.getLeegalityAuthToken();
        this.client = client;
        this.closurePdfGenerationService = closurePdfGenerationService;
    }
    public SuccessResponse addDetailsToClosureDbRepo(Closure closure) {
        ClosureDB closureDB = objectMapper.convertValue(closure, ClosureDB.class);
        Optional<ClosureDB> closerDBWrap = closureDBRepository.findByPhoneNumber(closure.getMobile());
        if(!closerDBWrap.isEmpty()) {
            _logger.info("========== Error -=-  duplication phone number not allowed {}", closure.getMobile());
            throw new BusinessException(ErrorCodes.CLIENT_UNDER_VERIFICATION, HttpStatus.BAD_REQUEST);
        }
//        _logger.info("-----------v closerDBWrap", closerDBWrap.get());
        closureDB.setPhoneNumber(closure.getMobile());
        closureDB.setClosureStatus("REQUESTED");
        PdfFile pdfFile = new PdfFile();
        pdfFile.setEmail(closure.getEmail());
        pdfFile.setMobile(closure.getMobile());
        pdfFile.setName(closure.getName());
        pdfFile.setPanCard(closure.getPanNumber());
        _logger.info("----------1");
        closureDBRepository.save(closureDB);
        _logger.info("----------1");
        pdfFile.setPdf(closurePdfGenerationService.pdfGenerationRequestForClosureDoc(closure));
        _logger.info("----------1");
        String signUrl = esignPdfusingLegality(pdfFile);
        return new SuccessResponse(signUrl);
    }

    private String esignPdfusingLegality(PdfFile pdfFile){
        String payload = "{\"file\":{\"name\":\"Re_" + pdfFile.getPanCard() + "\",\"file\":\"" + pdfFile.getPdf() + "\"},\"invitees\":[{\"name\":\"" + pdfFile.getName() + "\",\"email\":\"" + pdfFile.getEmail() + "\",\"phone\":\"" + pdfFile.getMobile() + "\",\"emailNotification\":\"true\",\"phoneNotification\":\"false\",\"webhook\":{\"success\":\""+leegalityRedirectUrl+pdfFile.getMobile()+"&isrekyc=CLOSURE"+"\",\"failure\":\""+leegalityRedirectUrl+pdfFile.getMobile()+"&isrekyc=CLOSURE"+"\",\"version\":\"2.3\"},\"redirectUrl\":\""+leegalityRedirectUrl+pdfFile.getMobile()+"&isrekyc=CLOSURE"+"\",\"signatures\":[{\"type\":\"AADHAAR\",\"config\":{\"authTypes\":[\"OTP\",\"BIO\",\"IRIS\"]}}]}],\"irn\":\"" + pdfFile.getPanCard() + "/RE\"}";
        Request request = new Request.Builder()
                .url(leegalityOrgURl)
                .addHeader("Content-Type" ,"application/json")
                .addHeader("X-Auth-Token", leegalityAuthToken)
                .post(RequestBody.create(MediaType.parse("application/json"), payload))
                .build();
        _logger.info("----------1");
        try (Response response = client.newCall(request).execute()){
            JsonNode rootNode = objectMapper.readTree(response.body().string());
            System.out.println("ESIGN API RESPONSE : "+rootNode.toString());
            _logger.info("----------1");
            JsonNode dataNode = rootNode.get("data");
            JsonNode invitationsNode = dataNode.get("invitations");
            String signUrl = invitationsNode.get(0).get("signUrl").asText();
            _logger.info("----------1");
            return signUrl;
        } catch(Exception e) {
            throw new BusinessException(ErrorCodes.E_SIGN_NOT_WORKED, HttpStatus.BAD_REQUEST);
        }
    }

    public RekycBackOfficeUserDetails userVerficationUsingOtp(String keyOfOtp , String userOtp) {
        OtpVerificationResponse otpVerificationResponse = otpService.verifyOtpOfUser(keyOfOtp, userOtp);
        if(!otpVerificationResponse.isVerified()) return null;
        Optional<ClosureDB> closerDBWrap = closureDBRepository.findByDpId(keyOfOtp);
        if(closerDBWrap.isPresent()) {
            _logger.info("========== Error -=-  duplication dpid number not allowed {}", keyOfOtp );
            throw new BusinessException(ErrorCodes.CLIENT_UNDER_VERIFICATION, HttpStatus.BAD_REQUEST);
        }
        String response = backOfficeDataApi.backOfficeApiDataUsingDpid(keyOfOtp);
        try {
            JsonNode rootNode1 = objectMapper.readTree(response);
            String jsonResponse = rootNode1.get(0).toString();
            Map<String, String> dataMap = objectMapper.readValue(jsonResponse, new TypeReference<Map<String, String>>() {});
            RekycBackOfficeUserDetails rekycUserDetails = new RekycBackOfficeUserDetails();
            /*
             * we might get json not converted error while we have not found any type of codes in our api
             * */
            rekycUserDetails.setEmail((dataMap.containsKey("emailno"))? (dataMap.get("emailno")) : (dataMap.get("email")));
            rekycUserDetails.setPhoneNumber((dataMap.containsKey("mobileno"))?(dataMap.get("mobileno")):(dataMap.get("phnos")));
            rekycUserDetails.setAccountStatus(dataMap.get("accountstatus"));
            rekycUserDetails.setName(dataMap.get("name"));
            rekycUserDetails.setPanNumber(dataMap.get("panno"));
            rekycUserDetails.setClientAddressOne(dataMap.get("add1"));
            rekycUserDetails.setClientAddressTwo(dataMap.get("add2"));
            rekycUserDetails.setCliendAddressThree(dataMap.get("add3"));
            rekycUserDetails.setClientAddressFour(dataMap.get("add4"));
            rekycUserDetails.setDateOfBirth(dataMap.get("dob"));
            rekycUserDetails.setFatherName(dataMap.get("fathername"));
            rekycUserDetails.setClientCode(keyOfOtp);
            rekycUserDetails.setPincode(dataMap.get("pincode"));

            // rekyc user all bank details from backoffice api
            RekycBankDetails rekycBankDetails = new RekycBankDetails();
            rekycBankDetails.setBankName(dataMap.get("bankname"));
            rekycBankDetails.setMicr(dataMap.get("micrcode"));
            rekycBankDetails.setIfsc(dataMap.get("ifsccode"));
            rekycBankDetails.setAccountNumber(dataMap.get("bankacno"));
            rekycBankDetails.setAccountType(dataMap.get("bankactype"));
            rekycUserDetails.setBankDetailsOfUser(rekycBankDetails);
            rekycUserDetails.setState(dataMap.get("state"));
            // new details
            rekycUserDetails.setCkycNumber(dataMap.get("ckycregnno"));
            rekycUserDetails.setGender(dataMap.get("gender"));
            rekycUserDetails.setUserDpId(dataMap.get("dpaccountno"));
            RekycUserDetailsDao rekycUserDetailsDao = new RekycUserDetailsDao();
            rekycUserDetailsDao.setClientCode(keyOfOtp);
            rekycUserDetailsDao.setName(dataMap.get("name"));
            rekycUserDetailsDao.setMobile((dataMap.containsKey("mobileno"))? (dataMap.get("mobileno")): (dataMap.get("phnos")));
            rekycUserDetailsDao.setEmail((dataMap.containsKey("emailno"))? (dataMap.get("emailno")) : (dataMap.get("email")));
            rekycUserDetailsDao.setPanNumber(dataMap.get("panno"));
            rekycUserDetailsDao.setLockStatus(RekycLockStatus.UNLOCKED);
            rekycUserDetailsDao.setRekycStatus(RekycStatus.CLIENT_DATA);
            rekycUserDetails.setXuserid(String.valueOf(rekycUserDetailsDao.getId()));
            rekycUserDetails.setUserSegmentsList(Arrays.asList(dataMap.get("activeexchange").split(",")));
            rekycUserDetails.setRekycStatus(RekycStatus.CLIENT_DATA);
            return rekycUserDetails;
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.REKYC_USER_BACK_OFFICE_DETAILS_IS_NOT_PERSENT_CURRENTLY, HttpStatus.BAD_REQUEST);
        }
    }
}
