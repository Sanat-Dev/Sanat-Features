package com.ekyc.nirman.entity.dto.BasicDetailsDto;

import com.ekyc.nirman.enums.AccountType;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BankDetailsDto{
    private String name ;
    @NotNull(message = "ifsc code can not be empty")
    private String ifsc ;
    @NotNull(message = "Account Number can not be empty")
    private String accountNumber ;
    @NotNull(message = "Account type can not be missing")
    private AccountType accountType;
}
