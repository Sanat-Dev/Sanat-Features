package com.ekyc.nirman.helper;

import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Objects;

@Service
public class CodeChallengerAndVerifierImpl implements CodeChallengerAndVerifier {
    @Resource(name = "redisDataCodeChallenger")
    private HashOperations<String, String, String> hashOperations;
    private  final String ALLOWED_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    @Override
    public CodeChallenger getCodeChallengerAndSaveCodeVerifier(String xuserid) {
        SecureRandom secureRandom = new SecureRandom();
        int verifierLength = 56;
        StringBuilder codeVerifier = new StringBuilder(verifierLength);
        for (int i = 0; i < verifierLength; ++i) {
            int randomCharIndex = secureRandom.nextInt(ALLOWED_CHARACTERS.length());
            codeVerifier.append(ALLOWED_CHARACTERS.charAt(randomCharIndex));
        }
        String codeChallengerdigi ;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hash = messageDigest.digest(codeVerifier.toString().getBytes(StandardCharsets.UTF_8));
            codeChallengerdigi = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
            hashOperations.put("codeChallengerInRedis" , xuserid, codeVerifier.toString());
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.CODE_CHALLENGER_ISSUE, HttpStatus.BAD_REQUEST);
        }
        return new CodeChallenger(codeChallengerdigi);
    }
    @Override
    public String getCodeVerifierOfUser(String xuserid) {
        String codeVerifier = hashOperations.get("codeChallengerInRedis", xuserid);
        if(Objects.isNull(codeVerifier)) throw new BusinessException(ErrorCodes.CODE_CHALLENGER_ISSUE, HttpStatus.BAD_REQUEST);
        return codeVerifier;
    }
}
