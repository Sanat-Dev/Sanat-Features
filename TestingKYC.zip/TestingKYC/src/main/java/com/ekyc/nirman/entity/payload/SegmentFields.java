package com.ekyc.nirman.entity.payload;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class SegmentFields {
    @NotNull(message = "nse cash option can not be null")
    private boolean nseCash;
    @NotNull(message = "nse future and option can not be null")
    private boolean nseFutureAndOption;
    @NotNull(message = "bse cds option can not be null")
    private boolean bseCds;
    @NotNull(message = "bse cash value can not be null")
    private boolean bseCash;
    @NotNull(message = "please provide bse future and option selection")
    private boolean bseFutureAndOption;
    private boolean ddpiOpted;
    @NotNull(message = "please provide plan type it can't be null")
    private String plan;
    private String financialProofDocument;
}
