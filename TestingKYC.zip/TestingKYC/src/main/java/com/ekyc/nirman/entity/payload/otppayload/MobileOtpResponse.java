package com.ekyc.nirman.entity.payload.otppayload;

import com.ekyc.nirman.enums.KycStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MobileOtpResponse {
    private String message ;
    private String userid ;
    private KycStatus kycStatus ;
}
