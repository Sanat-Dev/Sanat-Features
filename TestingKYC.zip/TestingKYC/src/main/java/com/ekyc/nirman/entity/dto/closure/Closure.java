package com.ekyc.nirman.entity.dto.closure;


import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class Closure {
    @NotNull(message = "cash segment value should not null")
    private boolean cash;
    @NotNull(message = "cash segment value should not null")
    private boolean fAndO;
    @NotNull(message = "fAndO segment value should not null")
    private boolean currency;
    @NotNull(message = "currency segment value should not null")
    private boolean mcx;
    @NotNull(message = "mcx segment value should not null")
    private boolean dpCheck;
    @NotNull(message = "dpId segment value should not null")
    @NotEmpty(message = "dpId segment value should not null")
    private String dpId;
    @NotNull(message = "name segment value should not null")
    @NotEmpty(message = "name segment value should not null")
    private String name;
    @NotNull(message = "panNumber should not null")
    @NotEmpty(message = "panNumber should not null")
    private String panNumber;
    @NotNull(message = "mobile should not null")
    @NotEmpty(message = "mobile should not null")
    private String mobile;
    private String newTransferDpId;
    private String newTransferClientCode;
    @NotNull(message = "reason For Closing should not null")
    @NotEmpty(message = "reason For Closing should not null")
    private String reasonForClosing;
    @NotNull(message = "email should not null")
    @NotEmpty(message = "email value should not null")
    private String email;
    @NotNull(message = "address should not null")
    @NotEmpty(message = "address value should not null")
    // additional field for user details
    private String address;
    @NotNull(message = "city should not null")
    @NotEmpty(message = "city value should not null")
    private String city;
    @NotNull(message = "state should not null")
    @NotEmpty(message = "state value should not null")
    private String state;
    @NotNull(message = "pincode should not null")
    @NotEmpty(message = "pincode value should not null")
    private String pincode;
    private String clientOldDpId;
    private String dpSupportImage;
}
