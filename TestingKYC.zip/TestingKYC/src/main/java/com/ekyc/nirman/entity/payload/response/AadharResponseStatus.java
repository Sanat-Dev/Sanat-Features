package com.ekyc.nirman.entity.payload.response;

import com.ekyc.nirman.enums.KycStatus;

public class AadharResponseStatus {
    private String name ;
    private String dob ;
    private String photo ;
    private KycStatus kycStatus ;
}
