package com.ekyc.nirman.entity.payload.otppayload;

import lombok.Data;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;

@Data
public class OtpInRedis implements Serializable {
    private String otp;
    private long expiryTimeStamp;
    public OtpInRedis(String otp, long expiryTimeMinutes){
        this.otp  = otp;
        this.expiryTimeStamp = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(expiryTimeMinutes);
    }
}
