package com.ekyc.nirman.entity.payload.response;

import com.ekyc.nirman.enums.KycStatus;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class EmailResponse {
    private String message ;
    private KycStatus kycStatus ;
}
