package com.ekyc.nirman.entity.rekyc;

import com.ekyc.nirman.entity.dto.PanCardDataDto;
import com.ekyc.nirman.entity.payload.innerservice.AadharResponseData;
import com.ekyc.nirman.enums.RekycStatus;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RekycDigilockerResponse {
    private String message;
    private RekycStatus rekycStatus;
    private AadharResponseData aadharResponseData;
    private PanCardDataDto panCardDataDto;
}
