package com.ekyc.nirman.entity.dto;

import com.ekyc.nirman.enums.Gender;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PanCardDataDto {
    private String panNumber ;
    private String name;
    private String dob ;
    private Gender gender ;
}
