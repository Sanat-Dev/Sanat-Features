package com.ekyc.nirman.helper;

import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;

public interface CodeChallengerAndVerifier {
     CodeChallenger getCodeChallengerAndSaveCodeVerifier(String xuserid);
     String getCodeVerifierOfUser(String xuserid);
}
