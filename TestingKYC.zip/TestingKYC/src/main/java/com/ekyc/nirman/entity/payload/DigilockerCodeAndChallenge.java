package com.ekyc.nirman.entity.payload;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DigilockerCodeAndChallenge {
    @NotNull(message = "required code challenger can not be null")
    private String code ;
}
