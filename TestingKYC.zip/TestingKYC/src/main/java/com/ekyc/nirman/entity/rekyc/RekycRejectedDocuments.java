package com.ekyc.nirman.entity.rekyc;

import com.ekyc.nirman.enums.RejectDocument;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Data
public class RekycRejectedDocuments {
    @NotNull
    @NotEmpty
    Map<RejectDocument, String> rejectedDocsList;
}
