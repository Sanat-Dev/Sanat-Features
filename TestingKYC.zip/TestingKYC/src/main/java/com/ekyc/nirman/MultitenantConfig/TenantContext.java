package com.ekyc.nirman.MultitenantConfig;

public class TenantContext {
    private static final ThreadLocal<String> Current_TENANT = new ThreadLocal<>();

    public static String getCurrentTenant(){
        return Current_TENANT.get();
    }

    public static void setCurrentTenant(String tenant){
        Current_TENANT.set(tenant);
    }
    public static void clear() {
        Current_TENANT.remove();
    }

}
