package com.ekyc.nirman.entity.rekyc;

import com.ekyc.nirman.entity.dto.BasicDetailsDto.NomineeDto;
import lombok.Data;

import javax.persistence.Column;
import java.util.List;

@Data
public class RekycSubmitDetails {
    private String incomeRange;
    private boolean isNewBankDefault;
    private String image;
    private String signature;
    private String bankProof ;
    private String financialProof;
    private boolean isBankProofImage;
    private boolean isFinancialProofImage ;
    private String netWorth;
    List<String> newSegmentList;
    List<NomineeDto> nominee ;
}
