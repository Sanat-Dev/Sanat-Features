package com.ekyc.nirman.entity.payload.innerservice;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BankProofUploadRequest {
    @NotNull(message = "bank validation proof is required")
    private String bankValidationProof;
}
