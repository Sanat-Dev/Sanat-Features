package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dao.AadharDataDao;
import com.ekyc.nirman.entity.dao.AddressDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dto.AccessTokenDto;
import com.ekyc.nirman.entity.dto.ListOfIssuedDocs;
import com.ekyc.nirman.enums.Gender;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.service.AdapterDigilockerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@Service
@Slf4j
public class AdapterDigilockerServiceImpl implements AdapterDigilockerService {

    @Autowired
    TenantConstants tenantConstants;

    private final OkHttpClient client;
    private final ObjectMapper objectMapper;
    private String client_id = tenantConstants.DIGI_LOCKER_CLIENT_ID;
    private String client_secret = tenantConstants.DIGI_LOCKER_CLIENT_SECRET;
    private String redirect_uri = tenantConstants.DIGI_LOCKER_REDIRECT_URI;
    private String rekyc_client_id = tenantConstants.DIGI_LOCKER_REKYC_CLIENT_ID;
    private String rekyc_client_secret = tenantConstants.DIGI_LOCKER_REKYC_CLIENT_SECRET;
    private String rekyc_redirect_uri = tenantConstants.DIGI_LOCKER_REKYC_REDIRECT_URI;
    public AdapterDigilockerServiceImpl(OkHttpClient client, ObjectMapper objectMapper) {
        this.client = client;
        this.objectMapper = objectMapper;
    }
    public AccessTokenDto getAccessTokenApi(boolean isRekyc, String codeVerifier, String code) {
        String clientId = isRekyc ?  rekyc_client_id : client_id;
        String clientSecret = isRekyc ? rekyc_client_secret: client_secret;
        String redirectUri = isRekyc ? rekyc_redirect_uri: redirect_uri;
        String jsonBody = "{\"grant_type\":\"authorization_code\",\"code\":\""+code+"\",\"client_id\":\""+clientId+"\",\"client_secret\":\""+clientSecret+"\",\"redirect_uri\":\""+redirectUri+"\",\"code_verifier\":\""+codeVerifier+"\"}";
        log.info("---------------newly created json body {}", jsonBody);
        Request request = new Request.Builder()
                .url("https://digilocker.meripehchaan.gov.in/public/oauth2/2/token")
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .header("Accept", "application/json")
                .post(RequestBody.create(MediaType.parse("application/json"), jsonBody))
                .build();

        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body().string();
            log.info("-------------- response {}", responseBody);
            try {
                // please make sure all value should be available in AccessTokenDto class and differenciate the int and string in that
                return objectMapper.readValue(responseBody, AccessTokenDto.class);
            } catch (Exception e) {
                throw new BusinessException(ErrorCodes.JSON_NOT_CONVERTED, HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.UNSUCCESSFUL_CALL_TO_DIGILK, HttpStatus.BAD_REQUEST);
        }
    }

    public String getPanCardUrlOfUserFromIssuedDocuments(String bearer) {
        Request request = new Request.Builder()
                .url("https://digilocker.meripehchaan.gov.in/public/oauth2/2/files/issued")
                .header("Authorization", "Bearer " +  bearer)
                .header("Accept", "application/json")
                .get()
                .build();
        ListOfIssuedDocs listOfDocuments = null;
        try (Response response = client.newCall(request).execute()) {
            try {
                listOfDocuments = objectMapper.readValue(response.body().string(), ListOfIssuedDocs.class);
            } catch (Exception e) {
                log.info("---------------------- not working here till");
                throw new BusinessException(ErrorCodes.JSON_NOT_CONVERTED, HttpStatus.BAD_REQUEST);
            }
        }
        catch (Exception e){
            log.info("--------------- till here not working aldfja");
            throw new BusinessException(ErrorCodes.DIGI_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST);
        }
        String panUri = null;
        for (int i = 0; i < listOfDocuments.getItems().size(); i++) {
            if (listOfDocuments.getItems().get(i).getDoctype().equals("PANCR")) {
                panUri = listOfDocuments.getItems().get(i).getUri();
            }
        }
        return panUri ;
    }
    public PanCardDao getPanCardDetailsFromXmlFile(String accessToken, String uri) {
        Request  request = new Request.Builder()
                .url("https://digilocker.meripehchaan.gov.in/public/oauth2/1/xml/"+ uri)
                .header("Authorization", "Bearer " + accessToken)
                .get()
                .build();
        String xmlFile= null;
        log.info("--------------------- pan card access token {} and uri {}", accessToken , uri);
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new BusinessException(ErrorCodes.DIGILOCKER_SERVER_IS_UNABLE_TO_BE_CALLED, HttpStatus.BAD_REQUEST);
            }
            try (InputStream responseStream = response.body().byteStream()) {
                log.info("-------------------------1");
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.parse(responseStream);
                log.info("-------------------------1");
                document.getDocumentElement().normalize();
                Element rootElement = document.getDocumentElement();
                log.info("-------------------------1");
                Element issuedElement = (Element) rootElement.getElementsByTagName("IssuedTo").item(0);
                log.info("-------------------------1");
                Element personData = (Element) issuedElement.getElementsByTagName("Person").item(0);
                log.info("-------------------------1");
                PanCardDao panCardDao = new PanCardDao();
                panCardDao.setPanNumber(rootElement.getAttribute("number"));
                panCardDao.setName(personData.getAttribute("name"));
                panCardDao.setDob(personData.getAttribute("dob"));
                panCardDao.setGender(Gender.fromValue(personData.getAttribute("gender")));
                log.info("-------------------------pancard  {} ", panCardDao);
                return panCardDao;
            }
        }
        catch (IOException e) {
            throw new BusinessException(ErrorCodes.DIGI_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST);
        } catch (ParserConfigurationException | SAXException e) {
            throw new BusinessException(ErrorCodes.XML_DATA_CANNOT_BE_CONVERTED, HttpStatus.BAD_REQUEST);
        }
    }
    public byte[] getPanCardVerificationPdf(String bearer, String uri) {
        Request request = new Request.Builder()
                .url("https://digilocker.meripehchaan.gov.in/public/oauth2/1/file/"+uri)
                .header("Authorization", "Bearer " +  bearer)
                .get()
                .build();
        try (Response response = client.newCall(request).execute()){
            if (response.isSuccessful()) {
                return response.body().bytes();
            } else {
                return null;
//                throw new BusinessException(ErrorCodes.UNSUCCESSFUL_CALL_TO_DIGILK, HttpStatus.BAD_REQUEST);
            }
        }
        catch (Exception e){
            return null;
//            throw new BusinessException(ErrorCodes.UNSUCCESSFUL_CALL_TO_DIGILK ,HttpStatus.BAD_REQUEST);
        }
    }
    public AadharDataDao get_e_AadhaarDataFromDigilocker(String bearer){
        Request request = new Request.Builder()
                .url("https://digilocker.meripehchaan.gov.in/public/oauth2/3/xml/eaadhaar")
                .header("Accept", "application/json")
                .header("Authorization", "Bearer " + bearer)
                .get()
                .build();
        try (Response response = client.newCall(request).execute()) {
            if(!response.isSuccessful()) {
                throw new BusinessException(ErrorCodes.UNSUCCESSFUL_RESPONSE_CODE_ERROR_FROM_DIGILOCKER, HttpStatus.BAD_REQUEST);
            }
            String jsonResponse = response.body().string() ;
            try (InputStream inputStream = new ByteArrayInputStream(jsonResponse.getBytes())) {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.parse(inputStream);
                document.getDocumentElement().normalize();
                Element rootElement = document.getDocumentElement();
                Element personAddressData = (Element) rootElement.getElementsByTagName("Poa").item(0);
                // setting manually aadhar data from xml file
                AddressDao addressDao = new AddressDao();
                addressDao.setCountry(personAddressData.getAttribute("country"));
                addressDao.setDistrict(personAddressData.getAttribute("dist"));
                addressDao.setHouseNumber(personAddressData.getAttribute("house"));
                addressDao.setLocation(personAddressData.getAttribute("loc"));
                addressDao.setPincode(personAddressData.getAttribute("pc"));
                addressDao.setState(personAddressData.getAttribute("state"));
                addressDao.setStreet(personAddressData.getAttribute("street"));
                addressDao.setVotingCenter(personAddressData.getAttribute("vtc"));
                // set data manually of aadhar data from xml file
                Element personInformation = (Element) rootElement.getElementsByTagName("Poi").item(0);
                Element photoElement = (Element)rootElement.getElementsByTagName("Pht").item(0);
                Element uidData = (Element)rootElement.getElementsByTagName("UidData").item(0);
                Element timeData = (Element)rootElement.getElementsByTagName("KycRes").item(0);
                AadharDataDao aadharDataDao = new AadharDataDao();
                aadharDataDao.setMaskAadharNumber(uidData.getAttribute("uid"));
                aadharDataDao.setName(personInformation.getAttribute("name"));
                aadharDataDao.setDob(personInformation.getAttribute("dob"));
                aadharDataDao.setGender(personInformation.getAttribute("gender"));
                aadharDataDao.setTimeStampGeneratedTimeActual(timeData.getAttribute("ts"));
                aadharDataDao.setTimeToLiveActual(timeData.getAttribute("ttl"));
                aadharDataDao.setDownloadedTimeInternal(OffsetDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));
                aadharDataDao.setCareOf(personAddressData.getAttribute("co"));
                aadharDataDao.setAadharProfilePhotoBase64(photoElement.getTextContent());
                aadharDataDao.setAadharXml(jsonResponse);
                aadharDataDao.setAadharAddress(addressDao);
                return aadharDataDao ;
            } catch (ParserConfigurationException | SAXException e) {
                throw new BusinessException(ErrorCodes.XML_DATA_CANNOT_BE_CONVERTED , HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.UNSUCCESSFUL_RESPONSE_CODE_ERROR_FROM_DIGILOCKER , HttpStatus.BAD_REQUEST);
        }
    }
}
