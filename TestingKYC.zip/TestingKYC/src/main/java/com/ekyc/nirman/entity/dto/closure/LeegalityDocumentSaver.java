package com.ekyc.nirman.entity.dto.closure;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class LeegalityDocumentSaver {
   @NotNull(message = "phone number can not be null")
   @NotEmpty(message = "phone number can not be empty")
   private String phoneNumber;
   @NotNull(message = "documentId can not be null")
   @NotEmpty(message = "documentId can not be empty")
   private String documentId;
   @NotNull(message = "pushvalue can not be null")
   @NotEmpty(message = "pushvalue can not be empty")
   private String pushvalue;
}
