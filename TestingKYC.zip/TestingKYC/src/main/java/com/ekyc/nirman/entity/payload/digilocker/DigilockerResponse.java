package com.ekyc.nirman.entity.payload.digilocker;

import com.ekyc.nirman.entity.dto.PanCardDataDto;
import com.ekyc.nirman.entity.payload.innerservice.AadharResponseData;
import com.ekyc.nirman.enums.KycStatus;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DigilockerResponse {
    private String message;
    private KycStatus kycStatus;
    private AadharResponseData aadharResponseData;
    private PanCardDataDto panCardDataDto;
}
