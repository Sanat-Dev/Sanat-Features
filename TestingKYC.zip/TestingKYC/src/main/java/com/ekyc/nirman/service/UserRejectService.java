package com.ekyc.nirman.service;

import com.ekyc.nirman.entity.dto.RejectedDocumentsData;
import com.ekyc.nirman.entity.payload.innerservice.CommonResponse;
import com.ekyc.nirman.enums.RejectDocument;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface UserRejectService {
    CommonResponse uploadUserRejectedDocument(UUID userId, RejectedDocumentsData rejectedDocumentsData) ;
    List<String> userRejectedListDocs(UUID userId);
}
