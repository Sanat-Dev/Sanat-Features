package com.ekyc.nirman.entity.dao.BasicDetailsDao;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Data
@Table(name = "guardian_details")
@Entity
public class GuardianDao {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator", parameters = {
            @org.hibernate.annotations.Parameter(name = "UUID_gen_strategy_class", value = "org.hibernate.id.UUID.CustomVersionOneStrategy") })
    @Column(name = "id" , columnDefinition = "BINARY(16)")
    private UUID id;
    @Column(name = "name", length = 30)
    private String name;
    @Column(name = "relation_with_nominee", length = 20)
    private String relationWithNominee;
    @Column(name = "id_proof", length = 20)
    private String idProof;
    @Column(name = "id_proof_no", length = 20)
    private String idProofNo;
    @Column(name = "address", length = 50)
    private String address ;
}
