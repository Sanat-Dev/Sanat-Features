package com.ekyc.nirman.entity.payload.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class RekycCommonResponse {
    private boolean isVerify;
    private String message;
}
