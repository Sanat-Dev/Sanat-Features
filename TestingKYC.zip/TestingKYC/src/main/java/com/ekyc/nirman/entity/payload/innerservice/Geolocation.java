package com.ekyc.nirman.entity.payload.innerservice;

import lombok.Data;

@Data
public class Geolocation {
    private String latitude ;
    private String longitude;
}
