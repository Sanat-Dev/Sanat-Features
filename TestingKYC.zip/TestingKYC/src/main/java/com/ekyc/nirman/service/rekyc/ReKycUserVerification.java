package com.ekyc.nirman.service.rekyc;

import com.ekyc.nirman.entity.dto.rekyc.RekycBackOfficeUserDetails;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;

public interface ReKycUserVerification {
    DeviceOtpResponse  userVerificationCodeSender(String dpid);
    RekycBackOfficeUserDetails userVerficationUsingOtp(String keyOfOtp , String userOtp);
}
