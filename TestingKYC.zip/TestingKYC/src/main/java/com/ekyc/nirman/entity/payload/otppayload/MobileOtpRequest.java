package com.ekyc.nirman.entity.payload.otppayload;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class MobileOtpRequest {
    @NotNull(message = "phone number fields can not be null")
    private String phone ;
    @NotNull(message = "user's otp should be there")
    private String otp ;
}
