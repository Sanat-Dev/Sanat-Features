package com.ekyc.nirman.service.otpservicehelper;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.payload.otppayload.*;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.security.SecureRandom;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class GenericOtpServiceImpl implements GenericOtpService {

    @Autowired
    TenantConstants tenantConstant;

    OkHttpClient client = new OkHttpClient();
    private final ObjectMapper objectMapper;
    private String baseUrl = tenantConstant.NOTIFICATION_SERVICE_URL;
    @Resource(name = "redisTemplate")
    private HashOperations<String,String, OtpInRedis> hashOperations;

    public GenericOtpServiceImpl(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    @Async
    public void sendOtpToUser(String value, NotificationType notificationType, Map<String, String> requestModel) {
        log.info("----------------- user otp details to send {} " , requestModel);
//        code to send otp in user phone
        NotificationRequest notificationRequest = NotificationRequest.builder()
                .to(value)
                .subject("Otp Verification")
                .templateType("NIRMAN_OTP_VERIFICATION")
                .model(requestModel)
                .build();
        log.info("-----------------------{}", notificationRequest);
        // added client name to modify notification service according to client
        Request request = new Request.Builder()
                .url(baseUrl +"?type=" + notificationType.getValue())
                .addHeader("Content-Type" ,"application/json")
                .addHeader("CLIENTNAME", "NIRMAN")
                .post(RequestBody.create(okhttp3.MediaType.parse("application/json"), serializeToJson(notificationRequest)))
                .build();
        try (Response response = client.newCall(request).execute()) {
        } catch (Exception e){
            throw new BusinessException(ErrorCodes.NOTIFICATION_SERVICE_IS_NOT_AVAILABLE, HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    public OtpVerificationResponse verifyOtpOfUser(String keyOfOtp , String userOtp) {
        OtpInRedis storedOtp = hashOperations.get("OtpInRedis", keyOfOtp);
        if(Objects.isNull(storedOtp)) {
            throw new BusinessException(ErrorCodes.UNAUTHORIZED_USER_REQUEST_FOR_OTP, HttpStatus.UNAUTHORIZED);
        }
        log.info("---------------- stored otp {} -- ", storedOtp);
        if(storedOtp.getOtp().equals(userOtp) && storedOtp.getExpiryTimeStamp() >= System.currentTimeMillis()) {
            return OtpVerificationResponse.builder().isVerified(true).message("Otp is valid").build();
        }
        return OtpVerificationResponse.builder().isVerified(false).message("Your otp is invalid").build();
    }

    @Override
    public String generateOtpForDevice() {
        SecureRandom secureRandom = new SecureRandom();
        int otpValue = secureRandom.nextInt(10000);
        return String.format("%04d" , otpValue);
    }

    @Override
    public void saveOtpInRedisCacheMemory(String keyOfOtp, String otp , int expiryTimeMinutes) {
        log.info("----------------- otp for user, save Otp in redis key - {} -- otp {}" ,keyOfOtp, otp);
        OtpInRedis otpInRedis = new OtpInRedis(otp, expiryTimeMinutes);
        hashOperations.put("OtpInRedis" , keyOfOtp, otpInRedis);
    }
    private String serializeToJson(NotificationRequest notificationRequest) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(notificationRequest);
        }
        catch (Exception e){
            throw new BusinessException(ErrorCodes.NOTIFICATION_SERVICE_CANNOT_BE_SERLIZED, HttpStatus.BAD_REQUEST);
        }
    }
}
