package com.ekyc.nirman.service.rekyc;

import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationRequest;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpRequest;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;
import com.ekyc.nirman.enums.NotificationType;

import java.util.UUID;

public interface RekycUserUpdateMobileAndEmail {
    DeviceOtpResponse sendOtpToUserRequestedDevice(NotificationType notificationType, DeviceOtpRequest deviceOtpRequest);
    OtpVerificationResponse verifyAndUpdateUserRequestedDeviceDetails(UUID xuserid, NotificationType notificationType , OtpVerificationRequest otpRequest);
}
