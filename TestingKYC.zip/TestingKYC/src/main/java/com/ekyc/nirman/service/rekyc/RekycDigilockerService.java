package com.ekyc.nirman.service.rekyc;

import com.ekyc.nirman.entity.payload.DigilockerCodeAndChallenge;
import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.entity.rekyc.RekycDigilockerResponse;

import java.util.UUID;

public interface RekycDigilockerService {
    RekycDigilockerResponse getUserDocumentsDataFromDigilockerApi(UUID xuserid , DigilockerCodeAndChallenge digilockerCodeAndChallenge);
    CodeChallenger createCodeChallengerAndSaveCodeVerifier(String xuserid);
}
