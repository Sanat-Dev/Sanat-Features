package com.ekyc.nirman.service.otpservicehelper;

import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.enums.NotificationType;

import java.util.Map;

public interface GenericOtpService {
    void sendOtpToUser(String value, NotificationType notificationType, Map<String, String> requestModel);
    OtpVerificationResponse verifyOtpOfUser(String keyOfOtp , String userOtp);
    String generateOtpForDevice();
    void saveOtpInRedisCacheMemory(String keyOfOtp, String otp , int expiryTimeMinutes);
}
