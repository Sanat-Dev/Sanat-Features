package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dao.AddressDao;
import com.ekyc.nirman.entity.dao.BasicDetailsDao.*;
import com.ekyc.nirman.entity.dao.ImageSignatureDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.BankDetailsDto;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.BasicUserInfoDto;
import com.ekyc.nirman.entity.dto.BasicDetailsDto.ListofNomineeMembersInfo;
import com.ekyc.nirman.entity.payload.SegmentFields;
import com.ekyc.nirman.entity.payload.innerservice.*;
import com.ekyc.nirman.enums.AccountType;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.repository.*;
import com.ekyc.nirman.service.UserDetailService;
import com.ekyc.nirman.service.pennydroppayment.PaymentVerificationAndDetails;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserDetailServiceImpl implements UserDetailService {

    @Autowired
    TenantConstants tenantConstants;

    private final Logger _logger = LoggerFactory.getLogger(UserDetailServiceImpl.class);
    private final ObjectMapper objectMapper;
    private final AddressRepository addressRepository ;
    private final NomineeDetailRepository nomineeDetailRepository ;
    private final BasicUserDetailsRepository basicUserDetailsRepository;
    private final PanCardRepository panCardRepository ;
    private final UserDetailMainRepository userDetailMainRepository;
    private final BankDetailsRepository bankDetailsRepository ;
    private final ImageSignatureRepository imageSignatureRepository ;
    private final PaymentVerificationAndDetails paymentVerificationAndDetails;
    private final String clientCode ;
    private OkHttpClient client = new OkHttpClient();
    public UserDetailServiceImpl(final String clientCode , ObjectMapper objectMapper, AddressRepository addressRepository, NomineeDetailRepository nomineeDetailRepository, BasicUserDetailsRepository basicUserDetailsRepository, PanCardRepository panCardRepository, UserDetailMainRepository userDetailMainRepository, BankDetailsRepository bankDetailsRepository, ImageSignatureRepository imageSignatureRepository, PaymentVerificationAndDetails paymentVerificationAndDetails) {
        this.objectMapper = objectMapper;
        this.addressRepository = addressRepository;
        this.nomineeDetailRepository = nomineeDetailRepository;
        this.basicUserDetailsRepository = basicUserDetailsRepository;
        this.panCardRepository = panCardRepository;
        this.userDetailMainRepository = userDetailMainRepository;
        this.bankDetailsRepository = bankDetailsRepository;
        this.imageSignatureRepository = imageSignatureRepository;
        this.paymentVerificationAndDetails = paymentVerificationAndDetails;
        this.clientCode = tenantConstants.EKYC_CLIENT_CODE;
    }

    @Override
    public void userNomineeDetails(UUID xuserid , ListofNomineeMembersInfo listofBasicUserInfo) {
        if(listofBasicUserInfo.getListOfNomineeInfo().size() > 3){
            throw new BusinessException(ErrorCodes.NOMINEE_CANNOT_BE_MORE_THEN_THREE, HttpStatus.BAD_REQUEST);
        }
        Optional<UserDetailMainDao> user = userDetailMainRepository.findById(xuserid);
        if(user.isEmpty()) {
             throw new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST);
        }
        for(int i = 0 ; i < listofBasicUserInfo.getListOfNomineeInfo().size(); i++){
            NomineeDao nomineeDao = objectMapper.convertValue(listofBasicUserInfo.getListOfNomineeInfo().get(i), NomineeDao.class);
            nomineeDao.setAddressDao((objectMapper.convertValue(listofBasicUserInfo.getListOfNomineeInfo().get(i).getAddressDto(), AddressDao.class)));
            GuardianDao guardianDao = new GuardianDao();
            guardianDao.setName(listofBasicUserInfo.getListOfNomineeInfo().get(i).getGuardianName());
            guardianDao.setRelationWithNominee(listofBasicUserInfo.getListOfNomineeInfo().get(i).getGuardianRelation());
            guardianDao.setAddress(listofBasicUserInfo.getListOfNomineeInfo().get(i).getGuardianAddress());
            guardianDao.setIdProofNo(listofBasicUserInfo.getListOfNomineeInfo().get(i).getGuardianIdProofNumber());
            guardianDao.setIdProofNo(listofBasicUserInfo.getListOfNomineeInfo().get(i).getGuardianIdProof());
            nomineeDao.setGuardianDao(guardianDao);
            nomineeDao = nomineeDetailRepository.save(nomineeDao);
            if( i == 0) {
                user.get().setNomineeOne(nomineeDao.getId());
                _logger.info("---------------- i = 1 nominee is saved in user {}", nomineeDao.getName());
            }
            if( i == 1) {
                user.get().setNomineeTwo(nomineeDao.getId());
                _logger.info("----------------i = 2 nominee is saved in user {}", nomineeDao.getName());
            }
            if( i == 2) {
                user.get().setNomineeThree(nomineeDao.getId());
                _logger.info("----------------i = 3 nominee is saved in user {}", nomineeDao.getName());
            }
        }
        userDetailMainRepository.save(user.get());
        return ;
    }

    @Override
    public CommonResponse userBasicDetailsAdd(UUID xuserid, BasicUserInfoDto basicUserInfoDto) {
        _logger.info("--------------------------------basic ----------  {} ", basicUserInfoDto);
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        BasicUserInfoDao basicUserInfoDao = objectMapper.convertValue(basicUserInfoDto, BasicUserInfoDao.class);
        _logger.info("--------------------------------after saving ------ {} " , basicUserInfoDao);
        basicUserInfoDao = basicUserDetailsRepository.save(basicUserInfoDao);
        user.setBasicUserInformationId(basicUserInfoDao.getId());
        user.setKycStatus(KycStatus.BANK_DETAILS);
        userDetailMainRepository.save(user);
        return new CommonResponse("details succesfully added" , KycStatus.BANK_DETAILS );
    }
    @Override
    public CommonResponse bankDetailsAddAndVerify(UUID xuserid, BankDetailsDto bankDetailsDto){
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()-> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        PanCardDao pan = panCardRepository.findById(user.getPanCardId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_PAN_CARD_NOT_FOUND, HttpStatus.BAD_REQUEST));
        bankDetailsDto.setName(pan.getName());
        String fundId = this.paymentVerificationAndDetails.createFundAccountOfUser(bankDetailsDto);
        RazorPayResponse razorPayResponse =this.paymentVerificationAndDetails.validateBankDetailsOfUserUsingRazorPay(fundId);
        BankDetailsDao bankDetail = new BankDetailsDao();
        bankDetail.setAccountNumber(bankDetailsDto.getAccountNumber());
        bankDetail.setIfsc(bankDetailsDto.getIfsc());
        bankDetail.setBankRegisteredName(razorPayResponse.getRegisteredName());
        bankDetail.setPayoutId(razorPayResponse.getPayoutId());
        bankDetail.setPennyDropReason(razorPayResponse.getPennyDropReason());
        bankDetail.setAccountType(AccountType.SAVING);
        bankDetail.setStatus(razorPayResponse.getStatus());
        IfscCodeResponse ifscData  = this.paymentVerificationAndDetails.getBankDetailFromIfscCode(bankDetailsDto.getIfsc());
        bankDetail.setBankName(ifscData.getName());

        if(!Objects.isNull(ifscData.getMicr())) {
            bankDetail.setMicr(ifscData.getMicr());
        } else  bankDetail.setMicr("---------");
        bankDetail.setAddress(ifscData.getAddress());
        bankDetail.setBranch(ifscData.getBranch());
        _logger.info("------------------bank details {}", bankDetail);
        bankDetail = bankDetailsRepository.save(bankDetail);
        user.setBankDetailId(bankDetail.getId());
        CommonResponse cr = null ;
        if(Objects.isNull(razorPayResponse.getRegisteredName())) {
            user.setKycStatus(KycStatus.BANK_PROOF_UPLOAD);
            cr =  new CommonResponse("Entered Account Number is Invalid" , KycStatus.BANK_PROOF_UPLOAD);
        }
        if(!razorPayResponse.getRegisteredName().equalsIgnoreCase(pan.getName())){
            _logger.info("------------razorPayResponse Registered Name {} --- pan Name {}" , razorPayResponse.getRegisteredName(), pan.getName());
            cr =  new CommonResponse("Name is mismatched with your documents and required to submit bank verification details like(Bank statement and Cancelled Check) for easy process of ekyc", KycStatus.BANK_PROOF_UPLOAD);
            user.setKycStatus(KycStatus.BANK_PROOF_UPLOAD);
        }
        if(Objects.isNull(cr)) {
            user.setKycStatus(KycStatus.SEGMENT);
            cr = new CommonResponse("successfully added bank details", KycStatus.SEGMENT);
        }
        userDetailMainRepository.save(user);
        return cr ;
    }

    @Override
    public CommonResponse addSegmentDetailsOfUser(UUID xuserid, SegmentFields fields) {
        _logger.info("------------- segment fields value {}", fields);
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED , HttpStatus.BAD_REQUEST));
        if(user.getBasicUserInformationId() == null){
            throw new BusinessException(ErrorCodes.USER_PERSONAL_DETAILS_NOT_FOUND ,HttpStatus.BAD_REQUEST);
        }
        BasicUserInfoDao userInfoDao = basicUserDetailsRepository.findById(user.getBasicUserInformationId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        userInfoDao.setNseCash(fields.isNseCash());
        userInfoDao.setNseFutureAndOption(fields.isNseFutureAndOption());
        userInfoDao.setBseCds(fields.isBseCds());
        userInfoDao.setBseCash(fields.isBseCash());
        userInfoDao.setBseFutureAndOption(fields.isBseFutureAndOption());
        userInfoDao.setBrokerageAmount(fields.getPlan());
        userInfoDao.setDDPIOpted(fields.isDdpiOpted());
        userInfoDao.setFinancialProofDocument(fields.getFinancialProofDocument());
        user.setKycStatus(KycStatus.UPLOAD_PHOTO);
        userDetailMainRepository.save(user);
        basicUserDetailsRepository.save(userInfoDao);
        return new CommonResponse("successfully updated segment information ", KycStatus.UPLOAD_PHOTO);
    }

    @Override
    public CommonResponse addImageAndSignatureOfUser(UUID xuserid, ImageAndSignatureDto imageAndSignatureDto){
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED , HttpStatus.BAD_REQUEST));
        ImageSignatureDao userImage = new ImageSignatureDao();
        userImage.setImage(imageAndSignatureDto.getImage());
        userImage.setSignature(imageAndSignatureDto.getSignature());
        userImage.setLatitude(imageAndSignatureDto.getGeolocation().getLatitude());
        userImage.setLongitude(imageAndSignatureDto.getGeolocation().getLongitude());
        userImage.setAddress(locationOfUserUsingGoogleApi(imageAndSignatureDto.getGeolocation()));
        imageSignatureRepository.save(userImage);
        user.setImageAndSignatureId(userImage.getId());
        user.setClientCode(generateClientCodeFromDatabase());
        user.setKycStatus(KycStatus.THANK_YOU);
        user.setSubscriptionList(new SubscriptionList());
        userDetailMainRepository.save(user);
//        PdfFile pdfFile = pdfConverterService.convertIntoPdf(xuserid);
//        return legalityService.esignPdfusingLegality(pdfFile);
        return CommonResponse.builder()
                .kycStatus(KycStatus.THANK_YOU)
                .message("Your trust in us means the world. Thank you for selecting us.").build();
    }
    public CommonResponse insertBankProofInDatabase(UUID xuserid, BankProofUploadRequest bankProofUploadRequest) {
        UserDetailMainDao user = this.userDetailMainRepository.findById(xuserid).orElseThrow(() -> new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        BankDetailsDao bankDetailOfUser = this.bankDetailsRepository.findById(user.getBankDetailId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_PERSONAL_DETAILS_NOT_FOUND, HttpStatus.BAD_REQUEST));
        bankDetailOfUser.setBankValidationProof(bankProofUploadRequest.getBankValidationProof());
        this.bankDetailsRepository.save(bankDetailOfUser);
        return CommonResponse.builder().message("Bank Proof successfull uploaded").kycStatus(KycStatus.SEGMENT).build();
    }

    public String generateClientCodeFromDatabase() {
        Optional<UserDetailMainDao> userDBOptional = userDetailMainRepository.findTopByOrderByClientCodeDesc();
        if(userDBOptional.isPresent()) {
            String clientCode = userDBOptional.get().getClientCode();
            _logger.info("--------------client code {}", clientCode);
            return "0"+(Integer.valueOf(clientCode)+1);
        } else {
            _logger.info("--------------client code is empty ");
            return this.clientCode;
        }
    }
    private String locationOfUserUsingGoogleApi(Geolocation geolocation) {
        Request request = new Request.Builder()
                .url("https://maps.googleapis.com/maps/api/geocode/json?latlng="+geolocation.getLatitude()+","+geolocation.getLongitude()+"&key=AIzaSyBxW7uK2DlTI1zrddb7d9eN_4hbdh1q2z4")
                .addHeader("Content-Type" ,"application/json")
                .get().build();
        try (Response response =  client.newCall(request).execute()) {
            String json = response.body().string();
            JsonNode jsonNode = objectMapper.readTree(json);
            String formattedAddress = jsonNode.path("results").get(0).path("formatted_address").asText();
            return formattedAddress;
        } catch (Exception e){
            return "geolocation : "+geolocation.getLatitude()+"----"+geolocation.getLatitude();
        }
    }
}
