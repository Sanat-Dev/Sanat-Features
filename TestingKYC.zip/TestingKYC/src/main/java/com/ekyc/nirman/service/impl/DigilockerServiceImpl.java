package com.ekyc.nirman.service.impl;

import com.ekyc.nirman.MultitenantConfig.TenantConstants;
import com.ekyc.nirman.entity.dao.AadharDataDao;
import com.ekyc.nirman.entity.dao.PanCardDao;
import com.ekyc.nirman.entity.dao.UserDetailMainDao;
import com.ekyc.nirman.entity.dto.*;
import com.ekyc.nirman.entity.payload.DigilockerCodeAndChallenge;
import com.ekyc.nirman.entity.payload.digilocker.CodeChallenger;
import com.ekyc.nirman.entity.payload.digilocker.PanCardDetails;
import com.ekyc.nirman.entity.payload.innerservice.AadharResponseData;
import com.ekyc.nirman.entity.payload.digilocker.DigilockerResponse;
import com.ekyc.nirman.enums.Gender;
import com.ekyc.nirman.enums.KycStatus;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.helper.CodeChallengerAndVerifier;
import com.ekyc.nirman.repository.*;
import com.ekyc.nirman.service.AdapterDigilockerService;
import com.ekyc.nirman.service.DigilockerService;
import com.ekyc.nirman.util.StringToJsonConverter;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.http.HttpClient;
import java.util.Base64;
import java.util.Objects;
import java.util.UUID;

@Service
public class DigilockerServiceImpl implements DigilockerService {

    @Autowired
    TenantConstants tenantConstants;

    private final Logger _logger = LoggerFactory.getLogger(DigilockerServiceImpl.class);
    private final ObjectMapper objectMapper;
    private final StringToJsonConverter stringToJsonConverter;
    private final AddressRepository addressRepository;
    private final AadharDataRepository aadharDataRepository;
    private final PanCardRepository panCardRepository;
    private final UserDetailMainRepository userDetailMainRepository;
    private final AdapterDigilockerService adapterDigilockerService;
    private final CodeChallengerAndVerifier codeChallengerAndVerifier;
    private String client_id  = tenantConstants.DIGI_LOCKER_CLIENT_ID;
    private String client_secret = tenantConstants.DIGI_LOCKER_CLIENT_SECRET;
    private String redirect_uri = tenantConstants.DIGI_LOCKER_REDIRECT_URI;
    private  final String ALLOWED_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    public DigilockerServiceImpl(ObjectMapper objectMapper, StringToJsonConverter stringToJsonConverter, AddressRepository addressRepository, AadharDataRepository aadharDataRepository, PanCardRepository panCardRepository, UserDetailMainRepository userDetailMainRepository, AdapterDigilockerService adapterDigilockerService, CodeChallengerAndVerifier codeChallengerAndVerifier) {
        this.objectMapper = objectMapper;
        this.stringToJsonConverter = stringToJsonConverter;
        this.addressRepository = addressRepository;
        this.aadharDataRepository = aadharDataRepository;
        this.panCardRepository = panCardRepository;
        this.userDetailMainRepository = userDetailMainRepository;
        this.adapterDigilockerService = adapterDigilockerService;
        this.codeChallengerAndVerifier = codeChallengerAndVerifier;
    }
    @Override
    public CodeChallenger getCodeChallenger(String xuserid){
        return codeChallengerAndVerifier.getCodeChallengerAndSaveCodeVerifier(xuserid);
    }

    @Override
    public DigilockerResponse uploadPanCardDetailsOfUser(UUID xuserid, PanCardDetails panCardDetails) {
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        if(user.getPanCardId()!= null) {
            return DigilockerResponse.builder()
                    .message("successfully fetched aadhar and pan card is uploaded by user")
                    .kycStatus(KycStatus.PERSONAL_INFO)
                    .build();
        }
        PanCardDao pan = new PanCardDao() ;
        pan.setName(panCardDetails.getName());
        pan.setPanNumber(panCardDetails.getPanNumber());
        pan.setDob(panCardDetails.getDob());
        AadharDataDao aadhar = aadharDataRepository.findById(user.getAdharId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        if(aadhar.getGender().equals("M")) {
            pan.setGender(Gender.MALE);
        } else if(aadhar.getGender().equals("F")) {
            pan.setGender(Gender.FEMALE);
        } else {
            pan.setGender(Gender.TRANSGENDER);
        }
        boolean image = false;
        if(!Objects.isNull(panCardDetails.getPanCardImage())) {
            image = panCardDetails.getPanCardImage().startsWith("data");
        }
        pan.setPanIsImage(image);
        if(image) {
            pan.setPan_pdf(Base64.getDecoder().decode(panCardDetails.getPanCardImage().substring(panCardDetails.getPanCardImage().indexOf("base64,")+7)));
        } else {
            pan.setPan_pdf(Base64.getDecoder().decode(panCardDetails.getPanCardImage()));
        }
        try {
            pan = panCardRepository.save(pan);
        } catch (Exception e) {
            _logger.info("------------- pan card already exist duplicate attempt of user");
            return DigilockerResponse.builder()
                    .message("successfully fetched aadhar and pan card is uploaded by user")
                    .kycStatus(KycStatus.VERIFICATION)
                    .build();
        }
        user.setPanCardId(pan.getId());
        userDetailMainRepository.save(user);
        AadharDataDao aadharDataDao = aadharDataRepository.findById(user.getAdharId()).orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED , HttpStatus.BAD_REQUEST));
        return DigilockerResponse.builder()
                .message("successfully fetched aadhar and pan card is uploaded by user")
                .kycStatus(KycStatus.VERIFICATION)
                .aadharResponseData(objectMapper.convertValue(aadharDataDao, AadharResponseData.class))
                .panCardDataDto(objectMapper.convertValue(pan , PanCardDataDto.class))
                .build();
    }
    @Override
    public DigilockerResponse getAccessTokenApi(UUID xuserid , DigilockerCodeAndChallenge digilockerCodeAndChallenge) {
        UserDetailMainDao user = userDetailMainRepository.findById(xuserid)
                .orElseThrow(()->new BusinessException(ErrorCodes.USER_NOT_REGISTERED, HttpStatus.BAD_REQUEST));
        String codeVerifier = codeChallengerAndVerifier.getCodeVerifierOfUser(String.valueOf(xuserid));
        AccessTokenDto accessTokenDto = adapterDigilockerService.getAccessTokenApi(false, codeVerifier, digilockerCodeAndChallenge.getCode());

        // aadhar details of user
        AadharDataDao aadhar = adapterDigilockerService.get_e_AadhaarDataFromDigilocker(accessTokenDto.getAccess_token());
        aadhar = aadharDataRepository.save(aadhar);
        String panUrl = adapterDigilockerService.getPanCardUrlOfUserFromIssuedDocuments(accessTokenDto.getAccess_token());
        // pan card details
        System.out.println("---------------"+panUrl+"--------");
        if(!Objects.isNull(panUrl)) {
            PanCardDao panCardDao = adapterDigilockerService.getPanCardDetailsFromXmlFile(accessTokenDto.getAccess_token(), panUrl);
//            panCardDao.setPan_pdf(adapterDigilockerService.getPanCardVerificationPdf(accessTokenDto.getAccess_token(), panUrl));
            byte[] panpdf = adapterDigilockerService.getPanCardVerificationPdf(accessTokenDto.getAccess_token(), panUrl);
            panCardDao.setPan_pdf(panpdf);
            panCardDao.setPanIsImage(false);
            try {
                panCardDao = panCardRepository.save(panCardDao);
            } catch (Exception e) {
                    // removing UUID aadhar id from aadhar repository
                _logger.info("------------- duplicate pancard found throw digilocker ------------");
                aadharDataRepository.deleteById(aadhar.getId());
                return DigilockerResponse.builder()
                        .message("Pan card is already exist can not be duplicate")
                        .kycStatus(KycStatus.VERIFICATION)
                        .build();
            }
            user.setPanCardId(panCardDao.getId());
            user.setName(panCardDao.getName());
            user.setPanNumber(panCardDao.getPanNumber());
            user.setAdharId(aadhar.getId());
            user.setKycStatus(KycStatus.PERSONAL_INFO);
            userDetailMainRepository.save(user);
            if(Objects.isNull(panpdf)) {
                return DigilockerResponse.builder()
                        .message("Pan is not verified through your account. Document is required")
                        .kycStatus(KycStatus.PAN_PROOF_REQUIRED)
                        .aadharResponseData(objectMapper.convertValue(aadhar, AadharResponseData.class))
                        .build();
            }
            return DigilockerResponse.builder()
                    .message("successfully fetched aadhar and pan card from digilocker")
                    .kycStatus(KycStatus.VERIFICATION)
                    .aadharResponseData(objectMapper.convertValue(aadhar, AadharResponseData.class))
                    .panCardDataDto(objectMapper.convertValue(panCardDao, PanCardDataDto.class))
                    .build();
        }
        else {
            user.setKycStatus(KycStatus.PAN_PROOF_REQUIRED);
            user.setAdharId(aadhar.getId());
            userDetailMainRepository.save(user);
        }
        return DigilockerResponse.builder()
                .message("Pan is not verified through your account. Document is required")
                .kycStatus(KycStatus.PAN_PROOF_REQUIRED)
                .aadharResponseData(objectMapper.convertValue(aadhar, AadharResponseData.class))
                .build();
    }
}
