package com.ekyc.nirman.entity.dto.rekyc;

public class RekycUserVerificationRequest {
    private String dpId ;
    private String otp ;
}
