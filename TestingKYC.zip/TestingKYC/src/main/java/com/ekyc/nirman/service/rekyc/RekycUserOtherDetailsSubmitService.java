package com.ekyc.nirman.service.rekyc;

import com.ekyc.nirman.entity.dto.rekyc.RekycCommonResponse;
import com.ekyc.nirman.entity.rekyc.RekycSubmitDetails;

import java.util.UUID;

public interface RekycUserOtherDetailsSubmitService {
    RekycCommonResponse addAdditionalUserDetails(UUID xuserid , RekycSubmitDetails rekycSubmitDetails) ;
     RekycCommonResponse submitEsignUrlUpload(UUID userid, String documentId);
}
