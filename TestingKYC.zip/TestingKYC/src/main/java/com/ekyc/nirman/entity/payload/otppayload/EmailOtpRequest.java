package com.ekyc.nirman.entity.payload.otppayload;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class EmailOtpRequest {
    @NotNull(message = "email should not empty")
    private String email ;
    @NotNull(message = "otp field not empty")
    private String otp ;
}
