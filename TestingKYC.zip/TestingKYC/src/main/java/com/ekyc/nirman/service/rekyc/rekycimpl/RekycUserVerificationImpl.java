package com.ekyc.nirman.service.rekyc.rekycimpl;

import com.ekyc.nirman.entity.dao.rekyc.RekycUserDetailsDao;
import com.ekyc.nirman.entity.dto.otpResponse.OtpVerificationResponse;
import com.ekyc.nirman.entity.dto.rekyc.RekycBankDetails;
import com.ekyc.nirman.entity.dto.rekyc.RekycBackOfficeUserDetails;
import com.ekyc.nirman.entity.payload.otppayload.DeviceOtpResponse;
import com.ekyc.nirman.enums.NotificationType;
import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.enums.RekycStatus;
import com.ekyc.nirman.exception.BusinessException;
import com.ekyc.nirman.exception.ErrorCodes;
import com.ekyc.nirman.repository.RekycUserRepository;
import com.ekyc.nirman.service.otpservicehelper.GenericOtpService;
import com.ekyc.nirman.service.rekyc.RekycBackOfficeDataApi;
import com.ekyc.nirman.service.rekyc.ReKycUserVerification;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RekycUserVerificationImpl implements ReKycUserVerification {
    private final Logger _logger = LoggerFactory.getLogger(RekycUserVerificationImpl.class);
    private final RekycBackOfficeDataApi backOfficeDataApi;
    private final ObjectMapper objectMapper;
    private final GenericOtpService otpService;
    public final RekycUserRepository rekycUserRepository;
    public RekycUserVerificationImpl(RekycBackOfficeDataApi backOfficeDataApi, ObjectMapper objectMapper, GenericOtpService otpService, RekycUserRepository rekycUserRepository) {
        this.backOfficeDataApi = backOfficeDataApi;
        this.objectMapper = objectMapper;
        this.otpService = otpService;
        this.rekycUserRepository = rekycUserRepository;
    }
    @Override
    public DeviceOtpResponse userVerificationCodeSender(String dpid) {
        String response = backOfficeDataApi.backOfficeApiDataUsingDpid(dpid);
        String email = null;
        String phoneNumber = null;
        _logger.info("-------------------- user verification code sender");
        try {
            JsonNode rootNode1 = objectMapper.readTree(response);
            String jsonResponse = rootNode1.get(0).toString();
            Map<String, String> dataMap = objectMapper.readValue(jsonResponse, new TypeReference<Map<String, String>>() {});
            _logger.info("--------------- map of value {}" , dataMap);
            if(dataMap.get("accountstatus").equals("Closed")) throw new BusinessException(ErrorCodes.REKYC_USER_DETAILS_NOT_EXIST, HttpStatus.UNAUTHORIZED);
            email = ((dataMap.containsKey("emailno"))? (dataMap.get("emailno")) : (dataMap.get("email")));
            phoneNumber = (dataMap.containsKey("mobileno"))? (dataMap.get("mobileno")): (dataMap.get("phnos"));
        } catch (Exception e) {
            throw new BusinessException(ErrorCodes.REKYC_USER_DETAILS_NOT_EXIST, HttpStatus.UNAUTHORIZED);
        }
        String otp = otpService.generateOtpForDevice();
        otpService.saveOtpInRedisCacheMemory(dpid , otp, 10);
        Map<String, String> requestModel = new HashMap<>();
        requestModel.put("name", email);
        requestModel.put("otp", otp);
        otpService.sendOtpToUser(phoneNumber, NotificationType.SMS, requestModel);
        requestModel.put("name" , phoneNumber);
        otpService.sendOtpToUser(email, NotificationType.EMAIL , requestModel);
        return new DeviceOtpResponse("otp is send in user phone and email");
    }

    @Override
    public RekycBackOfficeUserDetails userVerficationUsingOtp(String keyOfOtp , String userOtp) {
        _logger.info("-------------- user {} --- {}", keyOfOtp , userOtp);
        OtpVerificationResponse otpVerificationResponse = otpService.verifyOtpOfUser(keyOfOtp, userOtp);
        _logger.info("--------------------- otp verification data {}" , otpVerificationResponse);
        if(!otpVerificationResponse.isVerified()) return null;
        String response = backOfficeDataApi.backOfficeApiDataUsingDpid(keyOfOtp);
        try {
            JsonNode rootNode1 = objectMapper.readTree(response);
            String jsonResponse = rootNode1.get(0).toString();
            Map<String, String> dataMap = objectMapper.readValue(jsonResponse, new TypeReference<Map<String, String>>() {});
            RekycBackOfficeUserDetails rekycUserDetails = new RekycBackOfficeUserDetails();
            /*
            * we might get json not converted error while
            * */
            _logger.info("---------------------------- 1");
            rekycUserDetails.setEmail((dataMap.containsKey("emailno"))? (dataMap.get("emailno")) : (dataMap.get("email")));
            rekycUserDetails.setPhoneNumber((dataMap.containsKey("mobileno"))?(dataMap.get("mobileno")):(dataMap.get("phnos")));
            rekycUserDetails.setAccountStatus(dataMap.get("accountstatus"));
            _logger.info("---------------------------- 1");
            rekycUserDetails.setName(dataMap.get("name"));
            rekycUserDetails.setPanNumber(dataMap.get("panno"));
            _logger.info("---------------------------- 1");
            rekycUserDetails.setClientAddressOne(dataMap.get("add1"));
            rekycUserDetails.setClientAddressTwo(dataMap.get("add2"));
            rekycUserDetails.setCliendAddressThree(dataMap.get("add3"));
            rekycUserDetails.setClientAddressFour(dataMap.get("add4"));
            _logger.info("---------------------------- 1");
            rekycUserDetails.setDateOfBirth(dataMap.get("dob"));
            rekycUserDetails.setFatherName(dataMap.get("fathername"));
            rekycUserDetails.setClientCode(keyOfOtp);
            rekycUserDetails.setPincode(dataMap.get("pincode"));
            _logger.info("---------------------------- 1");
            // rekyc user all bank details from backoffice api
            RekycBankDetails rekycBankDetails = new RekycBankDetails();
                rekycBankDetails.setBankName(dataMap.get("bankname"));
                rekycBankDetails.setMicr(dataMap.get("micrcode"));
                rekycBankDetails.setIfsc(dataMap.get("ifsccode"));
                rekycBankDetails.setAccountNumber(dataMap.get("bankacno"));
                rekycBankDetails.setAccountType(dataMap.get("bankactype"));
                _logger.info("--------------  rekyc bank details {}",rekycBankDetails);
            _logger.info("---------------------------- 1");
            rekycUserDetails.setBankDetailsOfUser(rekycBankDetails);
            rekycUserDetails.setState(dataMap.get("state"));
            // new details
            rekycUserDetails.setCkycNumber(dataMap.get("ckycregnno"));
            rekycUserDetails.setGender(dataMap.get("gender"));
            _logger.info("---------------------------- 2 {}", keyOfOtp);
            Optional<RekycUserDetailsDao> rekycUserDao = rekycUserRepository.findByMobile(rekycUserDetails.getPhoneNumber());
            if(rekycUserDao.isEmpty()) {
                _logger.info("---------------------------- 12");
                RekycUserDetailsDao rekycUserDetailsDao = new RekycUserDetailsDao();
                rekycUserDetailsDao.setClientCode(keyOfOtp);
                rekycUserDetailsDao.setName(dataMap.get("name"));
                _logger.info("---------------------------- 13");
                rekycUserDetailsDao.setMobile((dataMap.containsKey("mobileno"))? (dataMap.get("mobileno")): (dataMap.get("phnos")));
                rekycUserDetailsDao.setEmail((dataMap.containsKey("emailno"))? (dataMap.get("emailno")) : (dataMap.get("email")));
                rekycUserDetailsDao.setPanNumber(dataMap.get("panno"));
                rekycUserDetailsDao.setLockStatus(RekycLockStatus.UNLOCKED);
                _logger.info("---------------------------- 14");
                rekycUserDetailsDao.setRekycStatus(RekycStatus.CLIENT_DATA);
                rekycUserDetailsDao = rekycUserRepository.save(rekycUserDetailsDao);
                rekycUserDetails.setXuserid(String.valueOf(rekycUserDetailsDao.getId()));
                rekycUserDetails.setUserSegmentsList(Arrays.asList(dataMap.get("activeexchange").split(",")));
                rekycUserDetails.setRekycStatus(RekycStatus.CLIENT_DATA);
                return rekycUserDetails;
            }
            _logger.info("---------------------------- 3");
            rekycUserDetails.setXuserid(String.valueOf(rekycUserDao.get().getId()));
            rekycUserDetails.setRekycStatus(rekycUserDao.get().getRekycStatus());
            rekycUserDetails.setLockStatus(rekycUserDao.get().getLockStatus());
            rekycUserDetails.setRekycStatus(rekycUserDao.get().getRekycStatus());
            _logger.info("---------------------------- 4");
            // user rejection list
            if(!Objects.isNull(rekycUserDao.get().getRejecetdDocsCommaSeprated())) {
                rekycUserDetails.setListOfRejectedDocuments(Arrays.asList(rekycUserDao.get().getRejecetdDocsCommaSeprated().split(",")));
            }
            _logger.info("---------------------------- 5");
            // segment list
            rekycUserDetails.setUserSegmentsList(Arrays.asList(dataMap.get("activeexchange").split(",")));
            _logger.info("---------------------------- 6");
            _logger.info("---------------------------- active exchange {}", dataMap.get("activeexchange"));
            return rekycUserDetails;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ErrorCodes.REKYC_USER_BACK_OFFICE_DETAILS_IS_NOT_PERSENT_CURRENTLY, HttpStatus.BAD_REQUEST);
        }
    }


}
