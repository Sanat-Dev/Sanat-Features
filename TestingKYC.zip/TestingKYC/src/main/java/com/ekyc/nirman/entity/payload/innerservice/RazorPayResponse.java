package com.ekyc.nirman.entity.payload.innerservice;

import lombok.Data;

@Data
public class RazorPayResponse {
    private String payoutId ;
    private String status ;
    private String registeredName ;
    private String pennyDropReason;
}
