package com.ekyc.nirman.entity.dto.BasicDetailsDto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BasicUserInfoDto {
    @NotNull(message = "marital status should not empty")
    private String maritalStatus ;
    private String spouseName ;
    @NotNull(message = "Mother name is required")
    private String motherName ;
    @NotNull(message = "Father name is required")
    private String fatherName ;
    @NotNull(message = "Education section is required")
    private String education ;
    @NotNull(message = "Trading Experience is required")
    private String tradingExperience ;
    @NotNull(message = "Occupation is required")
    private String occupation ;
    @NotNull(message = "Nominee should be false or true")
    private String nomineeCheck ;
    @NotNull(message = "Tax Residence should not be null")
    private String taxResidence ;
    @NotNull(message = "Net worth field is required")
    private String netWorth ;
    @NotNull(message = "Annual Salary should not be null")
    private String annualSalary;
    @NotNull(message = "politically Exposed either false or true")
    private String politicallyExposed ;
    private String nationality ;
    private String actionTakenBySebiOrAnyOtherAuthority;
    private String actionTakenBySebiOrAnyOtherAuthorityDescription ;
}
