package com.ekyc.nirman.MultitenantConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class TenantConstants {

    @Value("${defaultTenant}")
    private String defaultTenant;

    @Autowired
    private TenantPropertiesConfig tenantPropertiesConfig;

    private String tenantId;
    public String NOTIFICATION_SERVICE_URL;
    public String BACK_OFFICE_URL;
    public String EKYC_CLIENT_CODE;
    public String DIGI_LOCKER_CLIENT_ID;
    public String DIGI_LOCKER_CLIENT_SECRET;
    public String DIGI_LOCKER_REDIRECT_URI;
    public String DIGI_LOCKER_REKYC_CLIENT_ID;
    public String DIGI_LOCKER_REKYC_CLIENT_SECRET;
    public String DIGI_LOCKER_REKYC_REDIRECT_URI;
    public String RAZORPAY_FUND_CLIENT_CONTACT_ID;
    public String RAZORPAY_FUND_CLIENT_AUTH_USERNAME;
    public String RAZORPAY_FUND_CLIENT_AUTH_USERPASSWORD;
    public String RAZORPAY_FUND_CLIENT_ACCOUNT_NO;
    public String CLOSURE_LEEGALITY_CALLBACK_URL;
    public String LEEGALITY_ORG_URL;
    public String LEEGALITY_AUTH_TOKEN;
    public String SFTP_NIRMAN_USERNAME;
    public String SFTP_NIRMAN_PASSWORD;

    public TenantConstants(TenantPropertiesConfig tenantPropertiesConfig) {
        this.tenantId = TenantContext.getCurrentTenant();
        this.tenantPropertiesConfig = tenantPropertiesConfig;
        if(tenantId == null){
            tenantId = "tenant_2";
        }

        NOTIFICATION_SERVICE_URL = tenantPropertiesConfig.getNotificationUrl(tenantId);
        BACK_OFFICE_URL = tenantPropertiesConfig.getBackOfficeUrl(tenantId);
        EKYC_CLIENT_CODE = tenantPropertiesConfig.getEkycClientCode(tenantId);
        DIGI_LOCKER_CLIENT_ID = tenantPropertiesConfig.getDigiLockerClientId(tenantId);
        DIGI_LOCKER_CLIENT_SECRET = tenantPropertiesConfig.getDigiLockerClientSecret(tenantId);
        DIGI_LOCKER_REDIRECT_URI = tenantPropertiesConfig.getDigiLockerRedirectUri(tenantId);
        DIGI_LOCKER_REKYC_CLIENT_ID = tenantPropertiesConfig.getDigiLockerRekycClientId(tenantId);
        DIGI_LOCKER_REKYC_CLIENT_SECRET = tenantPropertiesConfig.getDigiLockerRekycClientSecret(tenantId);
        DIGI_LOCKER_REKYC_REDIRECT_URI = tenantPropertiesConfig.getDigiLockerRekycRedirectUri(tenantId);
        RAZORPAY_FUND_CLIENT_CONTACT_ID = tenantPropertiesConfig.getRazorpayFundClientContactId(tenantId);
        RAZORPAY_FUND_CLIENT_AUTH_USERNAME = tenantPropertiesConfig.getRazorpayFundClientAuthUsername(tenantId);
        RAZORPAY_FUND_CLIENT_AUTH_USERPASSWORD = tenantPropertiesConfig.getRazorpayFundClientAuthUserpassword(tenantId);
        RAZORPAY_FUND_CLIENT_ACCOUNT_NO = tenantPropertiesConfig.getRazorpayFundClientAccountNo(tenantId);
        CLOSURE_LEEGALITY_CALLBACK_URL = tenantPropertiesConfig.getClosureLeegalityCallbackUrl(tenantId);
        LEEGALITY_ORG_URL = tenantPropertiesConfig.getLeegalityOrgUrl(tenantId);
        LEEGALITY_AUTH_TOKEN = tenantPropertiesConfig.getLeegalityAuthToken(tenantId);
        SFTP_NIRMAN_USERNAME = tenantPropertiesConfig.getSftpNirmanUsername(tenantId);
        SFTP_NIRMAN_PASSWORD = tenantPropertiesConfig.getSftpNirmanPassword(tenantId);
    }
}
