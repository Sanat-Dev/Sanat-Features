package com.ekyc.nirman.entity.dao.closure;

import com.ekyc.nirman.entity.dao.BaseDao;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Data
@Table(name = "account_closure_details")
@Entity
public class ClosureDB extends BaseDao {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator", parameters = {
            @org.hibernate.annotations.Parameter(name = "UUID_gen_strategy_class", value = "org.hibernate.id.UUID.CustomVersionOneStrategy") })
    @Column(name = "id" , columnDefinition = "BINARY(16)")
    private UUID id;
    @Column(name = "cash")
    private boolean cash;
    @Column(name = "future_option_value")
    private boolean fAndO;
    @Column(name = "currency")
    private boolean currency;
    @Column(name = "mcx")
    private boolean mcx;
    @Column(name = "dp_check")
    private boolean dpCheck;
    @Column(name = "dp_id")
    private String dpId;
    private String name;
    @Column(name = "pan_number")
    private String panNumber;
    @Column(name = "phone_number")
    private String phoneNumber;
    @Column(name = "new_transfer_dpid")
    private String newTransferDpId;
    @Column(name = "new_transfer_client_code")
    private String newTransferClientCode;
    @Column(name = "reason_for_closing")
    private String reasonForClosing;
    @Column(name = "status")
    private String closureStatus;
    @Column(name = "leegality_docs_id")
    private String leegalityDocsId;
    @Lob
    @Column(name = "dp_support_photo")
    private String dpSupportImage;
}
