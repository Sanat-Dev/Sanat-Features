package com.ekyc.nirman.entity.dto.BasicDetailsDto;

import lombok.Data;

import java.util.List;

@Data
public class ListofNomineeMembersInfo {
    List<NomineeDto> listOfNomineeInfo ;
}
