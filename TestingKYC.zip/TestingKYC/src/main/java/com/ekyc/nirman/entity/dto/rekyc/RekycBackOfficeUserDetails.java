package com.ekyc.nirman.entity.dto.rekyc;

import com.ekyc.nirman.enums.RekycLockStatus;
import com.ekyc.nirman.enums.RekycStatus;
import lombok.Data;

import java.util.List;

@Data
public class RekycBackOfficeUserDetails {
    private String email ;
    private String phoneNumber ;
    private String name ;
    private String accountStatus ;
    private String state ;
    private String fatherName;
    private String clientAddressOne;
    private String clientAddressTwo ;
    private String cliendAddressThree ;
    private String clientAddressFour;
    private String panNumber ;
    private String clientCode ;
    private String pincode;
    private String dateOfBirth;
    private RekycBankDetails bankDetailsOfUser ;
    private String xuserid;
    private String gender;
    private String ckycNumber;
    private RekycStatus rekycStatus;
    private RekycLockStatus lockStatus;
    private String userDpId;

    List<String> listOfRejectedDocuments;
    List<String> userSegmentsList;
}
